<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EFIR - Register Account</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <style>
        .role-specific { display: none; }
    </style>
</head>
<body>

<nav class="navbar">
    <a href="index.jsp" class="nav-logo">
        <i class="fas fa-shield-halved"></i> EFIR <span>SYSTEM</span>
    </a>
    <ul class="nav-links">
        <li><a href="index.jsp">Home</a></li>
        <li><a href="login.jsp" class="btn-login">Login</a></li>
    </ul>
</nav>

<main class="container">
    <div class="form-container" style="max-width: 900px; margin-top: 2rem;">
        <div style="text-align: center; margin-bottom: 3rem;">
            <h1 class="fade-in">Create Official Account</h1>
            <p class="fade-in" style="color: var(--text-muted);">Join the unified Electronic First Information Report system</p>
        </div>

        <% String error = (String) request.getAttribute("error");
           if (error != null) { %>
            <div style="background: #FEF2F2; color: #EF4444; padding: 1rem; border-radius: 10px; margin-bottom: 2rem; border: 1px solid #FEE2E2;">
                <i class="fas fa-exclamation-triangle"></i> <%= error %>
            </div>
        <% } %>

        <form action="RegisterServlet" method="post" id="registerForm">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Full Name</label>
                    <input type="text" name="fullName" class="form-control" placeholder="John Doe" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="john@example.com" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Password</label>
                    <input type="password" name="password" id="password" class="form-control" placeholder="••••••••" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-shield"></i> Confirm Password</label>
                    <input type="password" id="confirmPassword" class="form-control" placeholder="••••••••" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-id-card"></i> Aadhaar Number</label>
                    <input type="text" name="aadhaarNo" class="form-control" placeholder="123456789012" pattern="[0-9]{12}" maxlength="12" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-phone"></i> Phone Number</label>
                    <input type="text" name="phone" class="form-control" placeholder="9876543210" pattern="[0-9]{10}" maxlength="10" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-briefcase"></i> Role</label>
                    <select name="role" id="roleSelector" class="form-control" required style="background: white;">
                        <option value="citizen">Citizen</option>
                        <option value="police">Police Officer</option>
                        <option value="admin">System Admin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-map-marker-alt"></i> Address</label>
                    <input type="text" name="address" class="form-control" placeholder="Street, City, State">
                </div>
            </div>

            <div id="policeFields" class="role-specific" style="margin-top: 1.5rem; animation: fadeIn 0.5s;">
                <div class="form-group">
                    <label style="color: var(--indigo);"><i class="fas fa-id-badge"></i> Police ID Card Number (Mandatory)</label>
                    <input type="text" name="policeIdCardNumber" id="policeIdInput" class="form-control" placeholder="POL-XXXX-YYYY" style="border-color: var(--indigo);">
                </div>
            </div>

            <div id="adminFields" class="role-specific" style="margin-top: 1.5rem; animation: fadeIn 0.5s;">
                <div class="form-group">
                    <label style="color: var(--primary);"><i class="fas fa-key"></i> Authoritative ID (Mandatory)</label>
                    <input type="text" name="authoritativeId" id="adminIdInput" class="form-control" placeholder="ADM-XXXX-YYYY" style="border-color: var(--primary);">
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 1.2rem; margin-top: 2rem; font-size: 1.1rem;">
                Create Account <i class="fas fa-user-plus" style="margin-left: 0.5rem;"></i>
            </button>
        </form>

        <p style="text-align: center; margin-top: 2rem; color: var(--text-muted);">
            Already have an account? <a href="login.jsp" style="color: var(--accent); font-weight: 600; text-decoration: none;">Login instead</a>
        </p>
    </div>
</main>

<script>
    const roleSelector = document.getElementById('roleSelector');
    const policeFields = document.getElementById('policeFields');
    const adminFields = document.getElementById('adminFields');
    const policeIdInput = document.getElementById('policeIdInput');
    const adminIdInput = document.getElementById('adminIdInput');

    roleSelector.addEventListener('change', function() {
        policeFields.style.display = 'none';
        adminFields.style.display = 'none';
        policeIdInput.required = false;
        adminIdInput.required = false;

        if (this.value === 'police') {
            policeFields.style.display = 'block';
            policeIdInput.required = true;
        } else if (this.value === 'admin') {
            adminFields.style.display = 'block';
            adminIdInput.required = true;
        }
    });

    document.getElementById('registerForm').addEventListener('submit', function(e) {
        const pass = document.getElementById('password').value;
        const confirm = document.getElementById('confirmPassword').value;

        if (pass !== confirm) {
            e.preventDefault();
            alert('Passwords do not match!');
        }
    });
</script>

</body>
</html>