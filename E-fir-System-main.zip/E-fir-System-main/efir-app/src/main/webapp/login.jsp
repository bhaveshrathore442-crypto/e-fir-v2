<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EFIR - Secure Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<div class="bg-shape shape-1"></div>
<div class="bg-shape shape-2"></div>

<div class="split-container" style="display: flex; min-height: 100vh; perspective: 1000px;">
    <div class="split-left" style="flex: 1; display: flex; align-items: center; justify-content: center; padding: 4rem; background: rgba(15, 23, 42, 0.4); backdrop-filter: blur(10px);">
        <div class="hero-content" style="text-align: left;">
            <a href="index.jsp" class="nav-logo" style="font-size: 3rem; margin-bottom: 3rem;">
                <i class="fas fa-shield-halved" style="color: var(--neon-blue);"></i> EFIR <span>SYSTEM</span>
            </a>
            <h1 style="font-size: 4rem; line-height: 1.1; margin-bottom: 2rem;">Secure<br>System Access</h1>
            <p style="font-size: 1.25rem; color: var(--text-muted); max-width: 500px; margin-bottom: 4rem;">
                Access the official digital law enforcement portal. Authorized personnel and registered citizens only.
            </p>
            
            <div style="display: flex; gap: 4rem;">
                <div style="text-align: center;">
                    <div class="step-circle active" style="width: 60px; height: 60px; font-size: 1.5rem;">1</div>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 1rem;">Identify</p>
                </div>
                <div style="text-align: center;">
                    <div class="step-circle" style="width: 60px; height: 60px; font-size: 1.5rem;">2</div>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 1rem;">Authenticate</p>
                </div>
                <div style="text-align: center;">
                    <div class="step-circle" style="width: 60px; height: 60px; font-size: 1.5rem;">3</div>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 1rem;">Secure</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="split-right" style="flex: 1; display: flex; align-items: center; justify-content: center; padding: 4rem;">
        <div class="form-container" style="width: 100%; max-width: 500px; margin: 0; padding: 4rem;">
            <div style="text-align: center; margin-bottom: 3rem;">
                <div style="width: 100px; height: 100px; background: rgba(59, 130, 246, 0.1); border-radius: 30px; display: flex; align-items: center; justify-content: center; margin: 0 auto 2rem; border: 1px solid var(--glass-border);">
                    <i class="fas fa-user-shield" style="font-size: 3rem; color: var(--neon-blue);"></i>
                </div>
                <h2 style="font-size: 2.5rem; margin-bottom: 0.5rem;">Welcome</h2>
                <p style="color: var(--text-muted);">Enter credentials to proceed</p>
            </div>

            <% String error = (String) request.getAttribute("error");
               if (error != null) { %>
                <div style="background: rgba(239, 68, 68, 0.1); color: var(--danger); padding: 1.25rem; border-radius: 16px; margin-bottom: 2rem; border: 1px solid rgba(239, 68, 68, 0.2); text-align: center;">
                    <i class="fas fa-exclamation-triangle"></i> <%= error %>
                </div>
            <% } %>

            <% String success = (String) request.getAttribute("success");
               if (success != null) { %>
                <div style="background: rgba(16, 185, 129, 0.1); color: var(--success); padding: 1.25rem; border-radius: 16px; margin-bottom: 2rem; border: 1px solid rgba(16, 185, 129, 0.2); text-align: center;">
                    <i class="fas fa-check-circle"></i> <%= success %>
                </div>
            <% } %>

            <form action="LoginServlet" method="post">
                <% String redirect = request.getParameter("redirect");
                   if (redirect != null) { %>
                    <input type="hidden" name="redirect" value="<%= redirect %>">
                <% } %>

                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="name@gov.portal" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                </div>
                <div class="form-group">
                    <label>Portal Role</label>
                    <select name="role" class="form-control" required style="background: rgba(2, 6, 23, 0.5);">
                        <option value="citizen">Citizen</option>
                        <option value="police">Police Officer</option>
                        <option value="admin">System Admin</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 2rem; padding: 1.25rem;">
                    Authenticate <i class="fas fa-fingerprint" style="margin-left: 0.75rem;"></i>
                </button>
            </form>

            <div style="text-align: center; margin-top: 3rem;">
                <p style="color: var(--text-muted); font-size: 0.95rem;">
                    Portal access required? <a href="register.jsp" style="color: var(--neon-blue); font-weight: 700; text-decoration: none;">Create Citizen ID</a>
                </p>
                <div style="margin-top: 2rem;">
                    <a href="index.jsp" style="color: var(--text-muted); text-decoration: none; font-size: 0.85rem; transition: 0.3s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='#94a3b8'">
                        <i class="fas fa-arrow-left"></i> Return to Homepage
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>