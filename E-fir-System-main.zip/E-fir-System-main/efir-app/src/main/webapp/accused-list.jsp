<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.efir.model.Accused, java.util.List" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EFIR - Public Accused Records</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<nav class="navbar">
    <a href="index.jsp" class="nav-logo">
        <i class="fas fa-shield-halved"></i> EFIR <span>SYSTEM</span>
    </a>
    <ul class="nav-links">
        <li><a href="index.jsp">Home</a></li>
        <li><a href="TrackFIRServlet">Track Status</a></li>
        <li><a href="accused-list.jsp" class="active">Wanted List</a></li>
        <li><a href="LogoutServlet" class="btn-login">Logout</a></li>
    </ul>
</nav>

<main class="container">
    <div style="text-align: center; margin-bottom: 5rem; padding: 4rem 2rem; background: linear-gradient(to bottom, #f8fafc, transparent); border-radius: 40px;">
        <div class="badge badge-pending" style="margin-bottom: 1.5rem;">Public Safety Division</div>
        <h1 style="font-size: 3.5rem; letter-spacing: -2px; margin-bottom: 1rem;">Public Wanted Database</h1>
        <p style="color: var(--text-muted); font-size: 1.25rem; max-width: 700px; margin: 0 auto;">Stay informed about active suspects and wanted individuals. Reporting any information helps maintain community safety.</p>
    </div>

    <div class="card-grid" style="grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));">
        <%
            List<Accused> list = (List<Accused>) request.getAttribute("accusedList");
            if (list != null && !list.isEmpty()) {
                for (Accused a : list) {
                    boolean isWanted = a.getStatus().equalsIgnoreCase("Wanted") || a.getStatus().contains("Large");
        %>
        <div class="card fade-in" style="padding: 0; overflow: hidden; border: none; box-shadow: var(--shadow-xl); border-bottom: 8px solid <%= isWanted ? "#ef4444" : "#10b981" %>;">
            <div style="padding: 2.5rem;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 2rem;">
                    <div>
                        <h3 style="margin: 0; font-size: 1.5rem; letter-spacing: -0.5px;"><%= a.getName() %></h3>
                        <div style="margin-top: 5px;">
                            <span class="badge badge-active" style="background: #f1f5f9; color: var(--primary);"><%= a.getGender() %></span>
                            <span class="badge badge-active" style="background: #f1f5f9; color: var(--primary);"><%= a.getAge() %> Yrs</span>
                        </div>
                    </div>
                    <span class="badge badge-<%= isWanted ? "pending" : "completed" %>" style="font-size: 0.7rem; padding: 0.5rem 1rem;">
                        <%= a.getStatus() %>
                    </span>
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <div style="font-size: 0.7rem; font-weight: 800; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 0.5rem;">Last Known Coordinates</div>
                    <p style="font-size: 1rem; font-weight: 600; color: var(--primary);"><i class="fas fa-location-crosshairs" style="color: var(--secondary); margin-right: 0.5rem;"></i> <%= a.getAddress() %></p>
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <div style="font-size: 0.7rem; font-weight: 800; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 0.5rem;">Physical Identification</div>
                    <p style="font-size: 1rem; color: var(--text);"><%= a.getIdentificationMark() %></p>
                </div>

                <div style="background: #fef2f2; padding: 1.5rem; border-radius: 16px; border-left: 4px solid #ef4444;">
                    <div style="font-size: 0.65rem; font-weight: 900; color: #b91c1c; text-transform: uppercase; margin-bottom: 0.5rem; letter-spacing: 1px;">Case Narrative / History</div>
                    <p style="font-size: 0.9rem; color: #991b1b; line-height: 1.6; font-weight: 500;"><%= a.getCriminalHistory() %></p>
                </div>
                
                <button class="btn btn-outline" style="width: 100%; margin-top: 2rem; border-color: #cbd5e1;">Report Sightings <i class="fas fa-eye" style="margin-left: 0.5rem;"></i></button>
            </div>
        </div>
        <%
                }
            } else {
        %>
        <div style="grid-column: 1 / -1; text-align: center; padding: 10rem 2rem;">
            <div style="width: 100px; height: 100px; background: #f1f5f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 2rem; color: #cbd5e1;">
                <i class="fas fa-search" style="font-size: 3rem;"></i>
            </div>
            <h2 style="font-size: 2rem;">Zero Matches Found</h2>
            <p style="color: var(--text-muted); max-width: 400px; margin: 1rem auto;">The public wanted database currently has no active alerts for your region.</p>
            <a href="index.jsp" class="btn btn-primary" style="margin-top: 2rem;">Return to Command Center</a>
        </div>
        <% } %>
    </div>
</main>

<footer style="margin-top: 5rem; padding: 4rem; text-align: center; color: var(--text-muted); font-size: 0.9rem;">
    <p>© 2026 Electronic FIR System. Use of this information for vigilantism is strictly prohibited.</p>
</footer>

</body>
</html>
