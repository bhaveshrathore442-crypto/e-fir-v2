<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.efir.model.FIR, com.efir.model.User, java.util.List, java.util.Map" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EFIR - Command Center</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <style>
        .sidebar { width: 280px; background: var(--primary); color: white; min-height: 100vh; padding: 2rem; }
        .sidebar a { color: rgba(255,255,255,0.7); text-decoration: none; display: block; padding: 0.8rem 1rem; border-radius: 8px; margin-bottom: 0.5rem; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.1); color: white; }
        .status-pill { padding: 4px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; }
        .pill-pending { background: #FEF3C7; color: #92400E; }
        .pill-active { background: #DBEAFE; color: #1E40AF; }
        .pill-resolved { background: #D1FAE5; color: #065F46; }
    </style>
</head>
<body>

<div class="bg-shape shape-1"></div>
<div class="bg-shape shape-2"></div>

<%
    User loggedUser = (User) session.getAttribute("user");
    List<FIR> firList = (List<FIR>) request.getAttribute("firList");
    Map<String, Integer> stats = (Map<String, Integer>) request.getAttribute("stats");
    List<User> officers = (List<User>) request.getAttribute("officers");
    List<String> notifications = (List<String>) request.getAttribute("notifications");
%>

<div style="display: flex; min-height: 100vh; perspective: 2000px;">
    <!-- Sidebar -->
    <aside class="sidebar glass" style="background: rgba(2, 6, 23, 0.8); border-right: 1px solid var(--glass-border); width: 300px; padding: 3rem 2rem; display: flex; flex-direction: column;">
        <div style="margin-bottom: 4rem;">
            <a href="index.jsp" class="nav-logo" style="font-size: 1.5rem;">
                <i class="fas fa-shield-halved" style="color: var(--neon-blue);"></i> EFIR <span>COMMAND</span>
            </a>
        </div>
        
        <div style="flex: 1;">
            <small style="color: var(--text-muted); text-transform: uppercase; letter-spacing: 2px; font-weight: 800; font-size: 0.7rem; margin-bottom: 2rem; display: block;">Intelligence Hub</small>
            <nav style="display: flex; flex-direction: column; gap: 0.75rem;">
                <a href="javascript:void(0)" onclick="showTab('overview')" class="sidebar-link active" id="tab-link-overview">
                    <i class="fas fa-layer-group"></i> Neural Overview
                </a>
                <a href="javascript:void(0)" onclick="showTab('cases')" class="sidebar-link" id="tab-link-cases">
                    <i class="fas fa-database"></i> Case Matrix
                </a>
                <% if ("admin".equals(loggedUser.getRole())) { %>
                    <a href="javascript:void(0)" onclick="showTab('police')" class="sidebar-link" id="tab-link-police">
                        <i class="fas fa-users-viewfinder"></i> Force Management
                    </a>
                <% } %>
            </nav>
        </div>

        <div style="margin-top: auto;">
            <div class="glass" style="padding: 1.5rem; border-radius: 20px; background: rgba(59, 130, 246, 0.05); border: 1px solid var(--glass-border); margin-bottom: 2rem;">
                <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 0.5rem;">
                    <div style="width: 10px; height: 10px; background: var(--accent); border-radius: 50%; box-shadow: 0 0 10px var(--accent);"></div>
                    <span style="font-size: 0.8rem; font-weight: 700; color: var(--text);"><%= loggedUser.getFullName() %></span>
                </div>
                <small style="color: var(--neon-blue); font-weight: 800; text-transform: uppercase; font-size: 0.65rem;"><%= loggedUser.getRole() %> Clearanced</small>
            </div>
            <a href="LogoutServlet" class="btn btn-outline" style="width: 100%; padding: 0.85rem; border-color: rgba(239, 68, 68, 0.2); color: var(--danger);">
                <i class="fas fa-power-off"></i> Terminate Session
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main style="flex: 1; overflow-y: auto; background: transparent;">
        <!-- Top Bar -->
        <header style="background: rgba(2, 6, 23, 0.4); backdrop-filter: blur(20px); padding: 1.5rem 4rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--glass-border); position: sticky; top: 0; z-index: 100;">
            <h2 id="tab-title" style="margin: 0; font-size: 1.5rem; letter-spacing: -1px;">Systems Operational</h2>
            <div style="display: flex; gap: 2rem; align-items: center;">
                <div style="position: relative; cursor: pointer;">
                    <i class="fas fa-bell" style="font-size: 1.25rem; color: var(--text-muted);"></i>
                    <% if (notifications != null && !notifications.isEmpty()) { %>
                        <span style="position: absolute; top: -5px; right: -5px; background: var(--danger); color: white; width: 18px; height: 18px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.65rem; border: 2px solid var(--background);">
                            <%= notifications.size() %>
                        </span>
                    <% } %>
                </div>
                <div class="glass" style="width: 44px; height: 44px; border-radius: 14px; display: flex; align-items: center; justify-content: center; background: var(--secondary); border: 1px solid var(--neon-blue);">
                    <i class="fas fa-terminal"></i>
                </div>
            </div>
        </header>

        <div style="padding: 4rem;">
            <% if (request.getAttribute("success") != null) { %>
                <div class="glass" style="background: rgba(16, 185, 129, 0.1); border-color: var(--success); color: var(--success); padding: 1.25rem; border-radius: 20px; margin-bottom: 3rem; animation: slideUp 0.5s;">
                    <i class="fas fa-check-double"></i> <%= request.getAttribute("success") %>
                </div>
            <% } %>

            <!-- TAB: OVERVIEW -->
            <div id="tab-overview" class="tab-content active">
                <div class="card-grid" style="grid-template-columns: repeat(4, 1fr); margin-bottom: 4rem;">
                    <div class="card glass" style="text-align: center; border: 1px solid rgba(255,255,255,0.05);">
                        <i class="fas fa-folders" style="font-size: 2.5rem; margin-bottom: 1.5rem;"></i>
                        <h4 style="color: var(--text-muted); margin-bottom: 0.5rem; text-transform: uppercase; font-size: 0.75rem;">Database Load</h4>
                        <div style="font-size: 3rem; font-weight: 800; color: var(--text);"><%= stats != null ? stats.getOrDefault("Total", 0) : 0 %></div>
                    </div>
                    <div class="card glass" style="text-align: center; border: 1px solid rgba(245, 158, 11, 0.1);">
                        <i class="fas fa-satellite-radar" style="font-size: 2.5rem; margin-bottom: 1.5rem; color: #fbbf24;"></i>
                        <h4 style="color: var(--text-muted); margin-bottom: 0.5rem; text-transform: uppercase; font-size: 0.75rem;">Awaiting Intel</h4>
                        <div style="font-size: 3rem; font-weight: 800; color: #fbbf24;"><%= stats != null ? stats.getOrDefault("Pending", 0) : 0 %></div>
                    </div>
                    <div class="card glass" style="text-align: center; border: 1px solid rgba(59, 130, 246, 0.1);">
                        <i class="fas fa-microscope" style="font-size: 2.5rem; margin-bottom: 1.5rem; color: var(--neon-blue);"></i>
                        <h4 style="color: var(--text-muted); margin-bottom: 0.5rem; text-transform: uppercase; font-size: 0.75rem;">Active Ops</h4>
                        <div style="font-size: 3rem; font-weight: 800; color: var(--neon-blue);"><%= stats != null ? stats.getOrDefault("In Progress", 0) : 0 %></div>
                    </div>
                    <div class="card glass" style="text-align: center; border: 1px solid rgba(16, 185, 129, 0.1);">
                        <i class="fas fa-shield-circle-check" style="font-size: 2.5rem; margin-bottom: 1.5rem; color: var(--accent);"></i>
                        <h4 style="color: var(--text-muted); margin-bottom: 0.5rem; text-transform: uppercase; font-size: 0.75rem;">Archived Success</h4>
                        <div style="font-size: 3rem; font-weight: 800; color: var(--accent);"><%= stats != null ? stats.getOrDefault("Resolved", 0) : 0 %></div>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1.5fr 1fr; gap: 3rem;">
                    <div class="card glass" style="padding: 3rem;">
                        <h3 style="margin-bottom: 2rem; color: var(--neon-blue);"><i class="fas fa-bolt"></i> Real-time Alerts</h3>
                        <div style="display: flex; flex-direction: column; gap: 1.5rem;">
                            <% if (notifications != null && !notifications.isEmpty()) { %>
                                <% for(String n : notifications) { %>
                                    <div style="background: rgba(255,255,255,0.02); padding: 1.5rem; border-radius: 16px; border-left: 4px solid var(--neon-blue); display: flex; align-items: center; gap: 1.5rem;">
                                        <div style="background: var(--surface-light); width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                                            <i class="fas fa-info" style="font-size: 0.9rem;"></i>
                                        </div>
                                        <div style="flex: 1;">
                                            <p style="margin: 0; font-size: 0.95rem;"><%= n %></p>
                                            <small style="color: var(--text-muted);">Syncing with mainframe...</small>
                                        </div>
                                    </div>
                                <% } %>
                            <% } else { %>
                                <div style="text-align: center; padding: 4rem 0;">
                                    <i class="fas fa-radar" style="font-size: 3rem; color: var(--text-muted); margin-bottom: 1.5rem;"></i>
                                    <p style="color: var(--text-muted);">All sectors clear. No alerts detected.</p>
                                </div>
                            <% } %>
                        </div>
                    </div>

                    <div class="card glass" style="padding: 3rem; background: rgba(0, 242, 255, 0.02);">
                        <h3 style="margin-bottom: 2rem;"><i class="fas fa-wave-square"></i> System Load</h3>
                        <div style="height: 150px; display: flex; align-items: flex-end; gap: 1rem; padding-bottom: 1rem;">
                            <div style="flex: 1; height: 40%; background: var(--neon-blue); border-radius: 4px; box-shadow: 0 0 15px var(--neon-glow);"></div>
                            <div style="flex: 1; height: 75%; background: var(--secondary); border-radius: 4px;"></div>
                            <div style="flex: 1; height: 60%; background: var(--neon-purple); border-radius: 4px;"></div>
                            <div style="flex: 1; height: 90%; background: var(--accent); border-radius: 4px;"></div>
                        </div>
                        <div style="display: flex; justify-content: space-between; color: var(--text-muted); font-size: 0.75rem; text-transform: uppercase; font-weight: 800; margin-top: 1rem;">
                            <span>Reporting</span>
                            <span>Sync</span>
                            <span>Enc</span>
                            <span>Core</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB: CASES -->
            <div id="tab-cases" class="tab-content" style="display: none;">
                <div style="display: flex; gap: 1.5rem; margin-bottom: 3rem;">
                    <button class="btn btn-primary" onclick="filterCases('all')">Universal Feed</button>
                    <button class="btn btn-outline" onclick="filterCases('Pending')">Pending Intel</button>
                    <button class="btn btn-outline" onclick="filterCases('In Progress')">In Field</button>
                    <button class="btn btn-accent" onclick="filterCases('Resolved')">Archived</button>
                </div>

                <div class="table-container glass" style="border-radius: 32px; overflow: hidden; border: 1px solid var(--glass-border);">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: rgba(2, 6, 23, 0.4);">
                                <th style="padding: 2rem; text-align: left; color: var(--neon-blue);">IDENTIFIER</th>
                                <th style="padding: 2rem; text-align: left; color: var(--neon-blue);">UNIT / VECTOR</th>
                                <th style="padding: 2rem; text-align: left; color: var(--neon-blue);">STATUS</th>
                                <th style="padding: 2rem; text-align: left; color: var(--neon-blue);">PERSONNEL</th>
                                <th style="padding: 2rem; text-align: left; color: var(--neon-blue);">COMMAND</th>
                            </tr>
                        </thead>
                        <tbody id="cases-table-body">
                            <% if (firList != null) { 
                                 for (FIR f : firList) { %>
                                <tr class="case-row" data-status="<%= f.getStatus() %>" style="border-bottom: 1px solid var(--glass-border);">
                                    <td style="padding: 2rem;">
                                        <div style="font-weight: 800; font-family: 'Space Grotesk'; font-size: 1.15rem; color: var(--text);"><%= f.getFirNumber() %></div>
                                        <div style="font-size: 0.75rem; color: var(--neon-blue); text-transform: uppercase; font-weight: 800; margin-top: 5px;"><%= f.getIncidentType() %></div>
                                    </td>
                                    <td style="padding: 2rem;">
                                        <div style="font-size: 0.95rem; font-weight: 600;"><%= f.getPoliceStation() %></div>
                                        <div style="font-size: 0.8rem; color: var(--text-muted);"><%= f.getIncidentDate() %></div>
                                    </td>
                                    <td style="padding: 2rem;">
                                        <span class="badge" style="background: rgba(0, 242, 255, 0.1); border: 1px solid var(--neon-blue); color: var(--neon-blue); padding: 0.5rem 1.25rem; border-radius: 30px; font-size: 0.75rem; font-weight: 800;">
                                            <%= f.getStatus() %>
                                        </span>
                                    </td>
                                    <td style="padding: 2rem;">
                                        <% if ("admin".equals(loggedUser.getRole()) && (f.getAssignedPoliceId() == 0)) { %>
                                            <form action="AdminDashboardServlet" method="post" style="display: flex; gap: 0.5rem;">
                                                <input type="hidden" name="action" value="assign">
                                                <input type="hidden" name="firId" value="<%= f.getFirId() %>">
                                                <select name="policeId" class="form-control" style="font-size: 0.85rem; padding: 0.75rem; min-width: 150px;" required>
                                                    <option value="">Operational Unit</option>
                                                    <% if (officers != null) { for (User off : officers) { %>
                                                        <option value="<%= off.getUserId() %>"><%= off.getFullName() %></option>
                                                    <% } } %>
                                                </select>
                                                <button type="submit" class="btn btn-primary" style="padding: 0.5rem 1rem;"><i class="fas fa-plus"></i></button>
                                            </form>
                                        <% } else { %>
                                            <div style="font-size: 0.9rem; font-weight: 700;"><i class="fas fa-user-tie" style="margin-right:0.5rem; color:var(--text-muted);"></i> <%= f.getAssignedPoliceId() > 0 ? "UNIT-" + f.getAssignedPoliceId() : "AWAITING STAFF" %></div>
                                        <% } %>
                                    </td>
                                    <td style="padding: 2rem;">
                                        <form action="UpdateStatusServlet" method="post" style="display: flex; flex-direction: column; gap: 0.5rem;">
                                            <input type="hidden" name="firId" value="<%= f.getFirId() %>">
                                            <div style="display: flex; gap: 0.5rem;">
                                                <select name="status" class="form-control" style="font-size: 0.85rem; padding: 0.75rem; flex: 1;">
                                                    <option value="Pending" <%= "Pending".equals(f.getStatus()) ? "selected" : "" %>>PENDING</option>
                                                    <option value="In Progress" <%= "In Progress".equals(f.getStatus()) ? "selected" : "" %>>IN FIELD</option>
                                                    <option value="Resolved" <%= "Resolved".equals(f.getStatus()) ? "selected" : "" %>>ARCHIVED</option>
                                                </select>
                                                <button type="submit" class="btn btn-accent" style="padding: 0.5rem 1rem;"><i class="fas fa-sync"></i></button>
                                            </div>
                                            <input type="text" name="remarks" class="form-control" placeholder="Brief activity log..." style="font-size: 0.75rem; padding: 0.5rem;" required>
                                        </form>
                                    </td>
                                </tr>
                            <% } } %>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- TAB: POLICE -->
            <% if ("admin".equals(loggedUser.getRole())) { %>
            <div id="tab-police" class="tab-content" style="display: none;">
                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 4rem;">
                    <div>
                        <div class="table-container glass" style="border-radius: 32px; overflow: hidden; border: 1px solid var(--glass-border);">
                            <div style="padding: 2rem 3rem; background: rgba(2, 6, 23, 0.4); border-bottom: 1px solid var(--glass-border); display: flex; justify-content: space-between; align-items: center;">
                                <h3 style="margin: 0; color: var(--neon-blue);">Active Personnel</h3>
                                <div class="badge badge-active" style="background: rgba(59, 130, 246, 0.1); border: 1px solid var(--neon-blue); color: var(--neon-blue);"><%= officers != null ? officers.size() : 0 %> ONLINE</div>
                            </div>
                            <table style="width: 100%; border-collapse: collapse;">
                                <thead>
                                    <tr style="background: rgba(2, 6, 23, 0.2);">
                                        <th style="padding: 2rem; text-align: left;">OFFICER</th>
                                        <th style="padding: 2rem; text-align: left;">BADGE VECTOR</th>
                                        <th style="padding: 2rem; text-align: left;">LOAD</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <% if (officers != null) { for (User off : officers) { %>
                                        <tr style="border-bottom: 1px solid var(--glass-border);">
                                            <td style="padding: 2rem;">
                                                <div style="font-weight: 800; font-size: 1.1rem; color: var(--text);"><%= off.getFullName() %></div>
                                                <div style="font-size: 0.8rem; color: var(--text-muted);"><%= off.getEmail() %></div>
                                            </td>
                                            <td style="padding: 2rem;">
                                                <span style="font-family: 'Space Grotesk'; font-weight: 800; color: var(--neon-blue); letter-spacing: 2px;"><%= off.getPoliceIdCardNumber() %></span>
                                            </td>
                                            <td style="padding: 2rem;">
                                                <div style="display:flex; align-items:center; gap:1rem;">
                                                    <div style="flex: 1; height: 6px; background: var(--surface-light); border-radius: 3px; max-width: 100px;">
                                                        <div style="width: <%= Math.min(Integer.parseInt(off.getAuthoritativeId()) * 10, 100) %>%; height: 100%; background: var(--secondary); border-radius: 3px; box-shadow: 0 0 10px var(--neon-glow);"></div>
                                                    </div>
                                                    <strong style="font-size: 1.1rem;"><%= off.getAuthoritativeId() %></strong>
                                                </div>
                                            </td>
                                        </tr>
                                    <% } } %>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div>
                        <div class="form-container" style="margin-top: 0; padding: 4rem;">
                            <h2 style="font-size: 2.25rem; margin-bottom: 1rem;"><i class="fas fa-id-card" style="color: var(--neon-blue);"></i> Onboard Unit</h2>
                            <p style="color: var(--text-muted); margin-bottom: 3rem;">Commission new field personnel into the system matrix.</p>
                            <form action="AdminDashboardServlet" method="post">
                                <input type="hidden" name="action" value="addOfficer">
                                <div class="form-group">
                                    <label>Full Name</label>
                                    <input type="text" name="fullName" class="form-control" placeholder="IDENTIFIER" required>
                                </div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                                    <div class="form-group">
                                        <label>Official Node (Email)</label>
                                        <input type="email" name="email" class="form-control" placeholder="unit@governance.net" required>
                                    </div>
                                    <div class="form-group">
                                        <label>System Key (Password)</label>
                                        <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                                    </div>
                                </div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                                    <div class="form-group">
                                        <label>Aadhaar Number</label>
                                        <input type="text" name="aadhaarNo" class="form-control" placeholder="12-digit number" pattern="[0-9]{12}" maxlength="12" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Phone Number</label>
                                        <input type="text" name="phone" class="form-control" placeholder="10-digit number" pattern="[0-9]{10}" maxlength="10" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Badge Serial (Police ID)</label>
                                    <input type="text" name="policeIdCardNumber" class="form-control" placeholder="POL-X-001" required>
                                </div>
                                <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 2rem; padding: 1.5rem;">
                                    AUTHORIZE PERSONNEL <i class="fas fa-fingerprint" style="margin-left: 1rem;"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <% } %>
        </div>
    </main>
</div>

<script>
function showTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
    document.querySelectorAll('.sidebar-link').forEach(el => el.classList.remove('active'));
    
    document.getElementById('tab-' + tabId).style.display = 'block';
    document.getElementById('tab-link-' + tabId).classList.add('active');
    
    const titles = {
        'overview': 'Neural Network Overview',
        'cases': 'Case Matrix Interface',
        'police': 'Personnel Logistics'
    };
    document.getElementById('tab-title').innerText = titles[tabId];
}

function filterCases(status) {
    const rows = document.querySelectorAll('.case-row');
    rows.forEach(row => {
        if (status === 'all' || row.getAttribute('data-status') === status) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
</script>

</body>
</html>