<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EFIR - Error</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<nav class="navbar">
  <a href="index.jsp" class="navbar-brand">🛡️ EFIR <span class="badge">Gov</span></a>
  <ul class="navbar-links">
    <li><a href="index.jsp">Home</a></li>
  </ul>
</nav>

<div class="form-page">
  <div class="form-box" style="text-align:center;">

    <div style="font-size:64px; margin-bottom:16px;">⚠️</div>

    <h2 style="font-size:22px; font-weight:700; margin-bottom:10px;">
      Something Went Wrong
    </h2>

    <p style="color:var(--text-muted); font-size:14px; margin-bottom:28px;">
      An unexpected error occurred. Please try again or return to the home page.
    </p>

    <% String errorMsg = (String) request.getAttribute("errorMsg");
       if (errorMsg != null) { %>
      <div class="alert alert-error" style="display:block; margin-bottom:24px; text-align:left;">
        <%= errorMsg %>
      </div>
    <% } %>

    <div style="display:flex; gap:12px; justify-content:center; flex-wrap:wrap;">
      <a href="index.jsp" class="btn btn-primary">← Go to Home</a>
      <a href="javascript:history.back()" class="btn btn-outline">Go Back</a>
    </div>

  </div>
</div>

</body>
</html>