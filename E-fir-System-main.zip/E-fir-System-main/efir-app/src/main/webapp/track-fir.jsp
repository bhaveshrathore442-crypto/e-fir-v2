<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.efir.model.FIR" %>
<%@ page import="com.efir.model.CaseUpdate" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EFIR - Track Investigation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<div class="bg-shape shape-1"></div>
<div class="bg-shape shape-2"></div>

<%
    java.util.List<FIR> userFIRs = (java.util.List<FIR>) request.getAttribute("userFIRs");
    FIR fir = (FIR) request.getAttribute("fir");
    java.util.List<CaseUpdate> updates = (java.util.List<CaseUpdate>) request.getAttribute("caseUpdates");
%>

<nav class="navbar">
    <a href="index.jsp" class="nav-logo">
        <i class="fas fa-shield-halved"></i> EFIR <span>SYSTEM</span>
    </a>
    <ul class="nav-links">
        <li><a href="index.jsp">Home</a></li>
        <li><a href="file-fir.jsp">File FIR</a></li>
        <li><a href="LogoutServlet" class="btn-login">Logout</a></li>
    </ul>
</nav>

<main class="container" style="display: flex; gap: 3rem; padding: 4rem 10% 10rem;">
    <!-- Sidebar: Case History -->
    <aside style="flex: 0 0 320px;">
        <div class="sidebar glass" style="background: rgba(15, 23, 42, 0.6); padding: 2rem; border-radius: 32px; border: 1px solid var(--glass-border); position: sticky; top: 120px;">
            <h3 style="margin-bottom:2rem; font-size: 1.5rem;"><i class="fas fa-folder-open" style="color:var(--neon-blue); margin-right:0.75rem;"></i> My Reports</h3>
            <div style="display: flex; flex-direction: column; gap: 1rem;">
                <% if (userFIRs != null && !userFIRs.isEmpty()) { 
                    for (FIR f : userFIRs) { %>
                    <form action="TrackFIRServlet" method="post">
                        <input type="hidden" name="firId" value="<%= f.getFirNumber() %>">
                        <button type="submit" class="sidebar-link <%= (fir != null && f.getFirId() == fir.getFirId()) ? "active" : "" %>" style="width: 100%; border: none; cursor: pointer; text-align: left; background: transparent; font-family: inherit;">
                            <div style="font-weight: 700; font-size: 0.9rem;"><%= f.getFirNumber() %></div>
                            <div style="font-size: 0.75rem; opacity: 0.7;"><%= f.getIncidentType() %></div>
                        </button>
                    </form>
                <% } } else { %>
                    <p style="color: var(--text-muted); font-size: 0.9rem; text-align: center; padding: 2rem 0;">No cases found.</p>
                <% } %>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <div style="flex: 1;">
        <!-- Search Bar -->
        <div class="form-container" style="margin-top: 0; padding: 2rem 3rem; margin-bottom: 3rem;">
            <form action="TrackFIRServlet" method="post" style="display: flex; gap: 1rem; align-items: center;">
                <div style="position: relative; flex: 1;">
                    <i class="fas fa-search" style="position: absolute; left: 1.5rem; top: 50%; translate: 0 -50%; color: var(--text-muted);"></i>
                    <input type="text" name="firId" class="form-control" placeholder="Search by Case Number (FIR-YYYY-XXXX)" style="padding-left: 3.5rem; background: rgba(2, 6, 23, 0.4);">
                </div>
                <button type="submit" class="btn btn-primary" style="padding: 1.25rem 2.5rem;">Initialize Search</button>
            </form>
        </div>

        <% if (fir != null) { %>
            <!-- Case Intelligence Display -->
            <div id="caseDisplay" class="fade-in">
                <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 2rem;">
                    <div>
                        <h1 style="font-size: 3.5rem; margin-bottom: 0.5rem;"><%= fir.getFirNumber() %></h1>
                        <p style="color: var(--text-muted); font-size: 1.1rem;"><%= fir.getIncidentType() %> | Registered on <%= fir.getCreatedAt() %></p>
                    </div>
                    <div class="badge <%= "Pending".equals(fir.getStatus()) ? "badge-pending" : "badge-active" %>" style="padding: 1rem 2rem; font-size: 1rem; border-radius: 12px; background: rgba(59, 130, 246, 0.1); border: 1px solid var(--neon-blue); color: var(--neon-blue);">
                        <%= fir.getStatus() %>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
                    <section>
                        <!-- Incident Summary -->
                        <div class="card glass" style="margin-bottom: 2rem; padding: 2.5rem;">
                            <h3 style="margin-bottom: 1.5rem; font-size: 1.5rem; color: var(--neon-blue);">Investigation Parameters</h3>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2rem;">
                                <div>
                                    <label style="display: block; font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.5rem;">Incident Location</label>
                                    <p style="font-weight: 600;"><%= fir.getIncidentLocation() %></p>
                                </div>
                                <div>
                                    <label style="display: block; font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.5rem;">Jurisdiction</label>
                                    <p style="font-weight: 600;"><%= fir.getPoliceStation() %></p>
                                </div>
                            </div>
                            <div>
                                <label style="display: block; font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.5rem;">Narrative Report</label>
                                <p style="line-height: 1.8;"><%= fir.getDescription() %></p>
                            </div>
                        </div>

                        <!-- Investigation Timeline -->
                        <div class="card glass" style="padding: 2.5rem;">
                            <h3 style="margin-bottom: 3rem; font-size: 1.5rem; color: var(--neon-purple);"><i class="fas fa-stream"></i> Investigation Timeline</h3>
                            <div class="timeline">
                                <% if (updates != null && !updates.isEmpty()) { 
                                    for (CaseUpdate u : updates) { %>
                                    <div class="timeline-item">
                                        <div class="timeline-dot"></div>
                                        <div class="timeline-content">
                                            <span class="timeline-date"><%= u.getCreatedAt() %></span>
                                            <h4><%= u.getStatusAtTime() %></h4>
                                            <p style="margin-bottom: 1rem;"><%= u.getUpdateText() %></p>
                                            <div style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.8rem; opacity: 0.7;">
                                                <i class="fas fa-user-check" style="margin-bottom:0"></i> Logged by <%= u.getPoliceName() %>
                                            </div>
                                        </div>
                                    </div>
                                <% } } else { %>
                                    <div class="timeline-item">
                                        <div class="timeline-dot"></div>
                                        <div class="timeline-content">
                                            <span class="timeline-date">System Entry</span>
                                            <h4>FIR REGISTERED</h4>
                                            <p>Case has been successfully logged into the central database. Verification pending.</p>
                                        </div>
                                    </div>
                                <% } %>
                            </div>
                        </div>
                    </section>

                    <aside>
                        <!-- Handling Officer Card -->
                        <div class="card glass" style="border: 1px solid rgba(0, 242, 255, 0.2); background: rgba(0, 242, 255, 0.03); padding: 2.5rem;">
                            <h3 style="margin-bottom: 2rem; font-size: 1.25rem;">Assigned Officer</h3>
                            <% if (fir.getPoliceOfficerName() != null) { %>
                                <div style="text-align: center; margin-bottom: 2rem;">
                                    <div style="width: 100px; height: 100px; border-radius: 50%; background: var(--surface-light); margin: 0 auto 1.5rem; display: flex; align-items: center; justify-content: center; border: 2px solid var(--neon-blue); box-shadow: 0 0 20px rgba(0, 242, 255, 0.2);">
                                        <i class="fas fa-user-shield" style="font-size: 3rem; color: var(--neon-blue); margin-bottom: 0;"></i>
                                    </div>
                                    <h4 style="font-size: 1.5rem; color: #fff;"><%= fir.getPoliceOfficerName() %></h4>
                                    <p style="color: var(--neon-blue); font-size: 0.9rem; font-weight: 700;">INVESTIGATION HEAD</p>
                                </div>
                                <div style="display: flex; flex-direction: column; gap: 1.5rem; border-top: 1px solid var(--glass-border); padding-top: 1.5rem;">
                                    <div>
                                        <label style="display: block; font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase;">Direct Line</label>
                                        <p style="font-weight: 600;">Internal Encryption 0992</p>
                                        <p style="font-size: 0.9rem;">+91 90000 00000</p>
                                    </div>
                                    <div>
                                        <label style="display: block; font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase;">Command Post</label>
                                        <p style="font-weight: 600;"><%= fir.getPoliceStation() %></p>
                                    </div>
                                </div>
                            <% } else { %>
                                <div style="text-align: center; padding: 2rem 0;">
                                    <i class="fas fa-user-clock" style="font-size: 3rem; color: var(--text-muted); margin-bottom: 1.5rem;"></i>
                                    <p style="color: var(--text-muted);">Awaiting Officer Assignment</p>
                                </div>
                            <% } %>
                        </div>

                        <!-- Technical Assets (Evidence) -->
                        <div class="card glass" style="margin-top: 2rem; padding: 2rem;">
                            <h3 style="margin-bottom: 1.5rem; font-size: 1.25rem;">Media Assets</h3>
                            <% if (fir.getImageData() != null) { %>
                                <div class="preview-item glass" style="height: 180px; border-radius: 16px; position: relative;">
                                    <img src="ImageServlet?firId=<%= fir.getFirId() %>" style="width: 100%; height: 100%; object-fit: cover; border-radius: 16px;">
                                    <div style="position: absolute; bottom: 10px; right: 10px;">
                                        <a href="ImageServlet?firId=<%= fir.getFirId() %>" target="_blank" class="btn glass" style="padding: 0.5rem; border-radius: 8px;"><i class="fas fa-expand" style="font-size:1rem; margin-bottom:0"></i></a>
                                    </div>
                                </div>
                            <% } else { %>
                                <p style="color: var(--text-muted); font-size: 0.9rem; text-align: center; border: 1px dashed var(--glass-border); padding: 2rem; border-radius: 16px;">No attached assets</p>
                            <% } %>
                        </div>
                    </aside>
                </div>
            </div>
        <% } else if (request.getAttribute("notFound") != null) { %>
            <div class="card glass" style="text-align: center; padding: 5rem;">
                <i class="fas fa-satellite-slash" style="font-size: 4rem; color: var(--danger); margin-bottom: 2rem;"></i>
                <h2 style="color: var(--danger);"><%= request.getAttribute("notFound") %></h2>
                <p style="color: var(--text-muted); margin-top: 1rem;">Verification failed. Please authenticate case identification string.</p>
            </div>
        <% } else { %>
            <div class="card glass" style="text-align: center; padding: 8rem; border: 1px dashed var(--glass-border);">
                <i class="fas fa-radar" style="font-size: 5rem; color: var(--neon-blue); margin-bottom: 3rem; animation: pulse 2s infinite;"></i>
                <h2>Systems Operational</h2>
                <p style="color: var(--text-muted); margin-top: 1rem; max-width: 400px; margin-left: auto; margin-right: auto;">Enter a Case ID or select a report from the history panel to initialize synchronization.</p>
            </div>
        <% } %>
    </div>
</main>

</body>
</html>