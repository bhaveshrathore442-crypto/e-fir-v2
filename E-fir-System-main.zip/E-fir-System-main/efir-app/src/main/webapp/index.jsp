<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.efir.model.User" %>
<%
    User user = (User) session.getAttribute("user");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EFIR - Electronic First Information Report System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<div class="bg-shape shape-1"></div>
<div class="bg-shape shape-2"></div>

<nav class="navbar">
    <a href="index.jsp" class="nav-logo">
        <i class="fas fa-shield-halved"></i> EFIR <span>SYSTEM</span>
    </a>
    <ul class="nav-links">
        <li><a href="index.jsp">Home</a></li>
        <li><a href="TrackFIRServlet">Track Status</a></li>
        <li><a href="AccusedListServlet">Wanted List</a></li>
        <% if (user == null) { %>
            <li><a href="login.jsp" class="btn-login">Official Portal</a></li>
        <% } else { %>
            <% if ("admin".equals(user.getRole())) { %>
                <li><a href="AdminDashboardServlet">Admin Panel</a></li>
            <% } else if ("police".equals(user.getRole())) { %>
                <li><a href="AdminDashboardServlet">Police Portal</a></li>
            <% } else { %>
                <li><a href="file-fir.jsp">File FIR</a></li>
            <% } %>
            <li><a href="LogoutServlet" class="btn-login">Logout</a></li>
        <% } %>
    </ul>
</nav>

<header class="hero">
    <div class="hero-content">
        <div class="badge badge-active pulse" style="margin-bottom: 2rem; background: rgba(59, 130, 246, 0.2); border: 1px solid var(--neon-blue); color: var(--neon-blue);">
            Official Governance Portal
        </div>
        <h1 class="fade-in">Safeguarding<br>The Community</h1>
        <p class="fade-in" style="color: var(--text); font-weight: 500; text-shadow: 0 2px 4px rgba(0,0,0,0.5);">
            Digital Justice for Every Citizen. Report incidents securely, track progress in real-time, and experience a transparent legal process.
        </p>
        <div class="cta-group fade-in" style="display: flex; gap: 1.5rem; justify-content: center; margin-top: 3rem;">
            <% if (user == null) { %>
                <a href="register.jsp" class="btn btn-primary">Join the Portal <i class="fas fa-arrow-right"></i></a>
                <a href="login.jsp" class="btn btn-outline">Login <i class="fas fa-sign-in-alt"></i></a>
            <% } else { %>
                <a href="file-fir.jsp" class="btn btn-primary">File a New FIR <i class="fas fa-file-signature"></i></a>
                <a href="TrackFIRServlet" class="btn btn-outline">My Case History <i class="fas fa-history"></i></a>
            <% } %>
        </div>
        
        <div class="hero-image-container fade-in" style="margin-top: 5rem; perspective: 2000px;">
            <div class="hero-3d-card" style="transform: rotateX(15deg); transition: transform 0.5s;">
                <img src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=1200" 
                     alt="Law and Order" 
                     style="width: 100%; max-width: 900px; height: 400px; object-fit: cover; border-radius: 40px; border: 1px solid var(--glass-border); box-shadow: 0 50px 100px rgba(0,0,0,0.5);">
            </div>
        </div>
    </div>
</header>

<main class="container" style="padding: 0 10% 10rem;">
    <div class="card-grid">
        <div class="card">
            <i class="fas fa-lock"></i>
            <h3>Secure Submission</h3>
            <p>End-to-end encrypted reports with multi-factor authentication for total data integrity.</p>
        </div>
        <div class="card">
            <i class="fas fa-camera"></i>
            <h3>Evidence Management</h3>
            <p>High-speed upload for multi-media evidence including images and videos (JPG, PNG, MP4).</p>
        </div>
        <div class="card">
            <i class="fas fa-scale-balanced"></i>
            <h3>Real-time Tracking</h3>
            <p>Transparent timeline of your case from filing to closure with officer updates.</p>
        </div>
    </div>

    <section style="margin-top: 10rem; text-align: center;">
        <h2 style="margin-bottom: 5rem; font-size: 3rem; background: linear-gradient(to right, #fff, #64748b); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Official Portals</h2>
        <div class="card-grid">
            <div class="card" onclick="location.href='login.jsp'" style="cursor: pointer;">
                <i class="fas fa-user-shield"></i>
                <h4>Citizen Portal</h4>
                <p>Register complaints and track status</p>
                <a href="login.jsp" class="btn btn-outline" style="margin-top: 2rem; width: 100%;">Access Now</a>
            </div>
            <div class="card" onclick="location.href='login.jsp'" style="cursor: pointer;">
                <i class="fas fa-id-card"></i>
                <h4>Police Portal</h4>
                <p>Manage assigned cases and updates</p>
                <a href="login.jsp" class="btn btn-outline" style="margin-top: 2rem; width: 100%;">Internal Log</a>
            </div>
            <div class="card" onclick="location.href='login.jsp'" style="cursor: pointer;">
                <i class="fas fa-cog"></i>
                <h4>Admin Panel</h4>
                <p>System management and assignment</p>
                <a href="login.jsp" class="btn btn-outline" style="margin-top: 2rem; width: 100%;">Admin Login</a>
            </div>
        </div>
    </section>
</main>

<footer style="background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(20px); border-top: 1px solid var(--glass-border); padding: 5rem 10% 2rem;">
    <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 4rem;">
        <div>
            <a href="index.jsp" class="nav-logo" style="margin-bottom: 1.5rem;">
                <i class="fas fa-shield-halved"></i> EFIR <span>SYSTEM</span>
            </a>
            <p style="color: var(--text-muted); max-width: 300px;">Official Digital Portal for Law Enforcement and Judicial Transparency.</p>
        </div>
        <div style="display: flex; gap: 5rem;">
            <div>
                <h4 style="margin-bottom: 1.5rem; color: var(--neon-blue);">Helpdesk</h4>
                <p style="color: var(--text-muted);">1800-419-5555</p>
            </div>
            <div>
                <h4 style="margin-bottom: 1.5rem; color: var(--danger);">Emergency</h4>
                <p style="color: var(--text-muted);">Dial 100 / 112</p>
            </div>
        </div>
    </div>
    <div style="margin-top: 5rem; padding-top: 2rem; border-top: 1px solid var(--glass-border); text-align: center; color: var(--text-muted); font-size: 0.9rem;">
        © 2026 Electronic FIR System. Official Gov Portal. Built for Public Safety.
    </div>
</footer>

<script>
    document.addEventListener('mousemove', (e) => {
        const card = document.querySelector('.hero-3d-card');
        if (!card) return;
        const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
        const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
        card.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
    });
</script>

</body>
</html>