<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EFIR - File Official FIR</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <style>
        .step-content { display: none; margin-top: 2rem; animation: fadeIn 0.5s; }
        .step-content.active { display: block; }
        .image-preview-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 1rem; margin-top: 1rem; }
        .preview-item { position: relative; border-radius: 8px; overflow: hidden; height: 100px; border: 1px solid var(--border); }
        .preview-item img, .preview-item video { width: 100%; height: 100%; object-fit: cover; }
    </style>
</head>
<body>

<div class="bg-shape shape-1"></div>
<div class="bg-shape shape-2"></div>

<%
    com.efir.model.User user = (com.efir.model.User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp?redirect=file-fir.jsp");
        return;
    }
%>

<nav class="navbar">
    <a href="index.jsp" class="nav-logo">
        <i class="fas fa-shield-halved"></i> EFIR <span>SYSTEM</span>
    </a>
    <ul class="nav-links">
        <li><a href="index.jsp">Home</a></li>
        <li><a href="TrackFIRServlet">Track FIR</a></li>
        <li><a href="LogoutServlet" class="btn-login">Logout</a></li>
    </ul>
</nav>

<main class="container" style="padding: 4rem 10% 10rem;">
    <div class="form-container">
        <div class="steps">
            <div class="step active" id="s1">
                <div class="step-circle">1</div>
                <small style="color: var(--text-muted); font-weight: 600; text-transform: uppercase; font-size: 0.75rem;">Incident</small>
            </div>
            <div class="step" id="s2">
                <div class="step-circle">2</div>
                <small style="color: var(--text-muted); font-weight: 600; text-transform: uppercase; font-size: 0.75rem;">Suspect</small>
            </div>
            <div class="step" id="s3">
                <div class="step-circle">3</div>
                <small style="color: var(--text-muted); font-weight: 600; text-transform: uppercase; font-size: 0.75rem;">Evidence</small>
            </div>
        </div>

        <% String error = (String) request.getAttribute("error");
           if (error != null) { %>
            <div style="background: rgba(239, 68, 68, 0.1); color: var(--danger); padding: 1.25rem; border-radius: 16px; margin-bottom: 2rem; border: 1px solid rgba(239, 68, 68, 0.2); text-align: center;">
                <i class="fas fa-exclamation-triangle"></i> <%= error %>
            </div>
        <% } %>

        <form action="FileFIRServlet" method="post" enctype="multipart/form-data" id="multistepForm">
            <!-- Step 1: Incident Details -->
            <div class="step-content active" id="step1">
                <div style="margin-bottom: 3rem;">
                    <h2 style="font-size: 2.5rem; margin-bottom: 0.5rem;"><i class="fas fa-info-circle" style="color: var(--neon-blue);"></i> Incident Log</h2>
                    <p style="color: var(--text-muted);">Provide comprehensive details about the occurrence.</p>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div class="form-group">
                        <label>Crime Classification</label>
                        <select name="incidentType" class="form-control" required>
                            <option value="">-- Select Category --</option>
                            <option>Theft</option><option>Robbery</option><option>Cybercrime</option>
                            <option>Harassment</option><option>Assault</option><option>Fraud</option>
                            <option>Missing Person</option><option>Traffic Violation</option><option>Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Date of Event</label>
                        <input type="date" name="incidentDate" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Precise Location</label>
                        <input type="text" name="incidentLocation" class="form-control" placeholder="GPS coordinates or street address" required>
                    </div>
                    <div class="form-group">
                        <label>Legal Jurisdiction</label>
                        <select name="policeStation" class="form-control" required>
                            <option value="">-- Nearest Police Station --</option>
                            <option>AERODRUM</option><option>ANNAPURNA</option><option>AZADNAGAR</option>
                            <option>BADGONDA</option><option>BANGANGA</option><option>BETMA</option>
                            <option>BHAWARKUA</option><option>CEN.KOTWALI</option><option>CHANDAN NAGAR</option>
                            <option>CHHATRIPURA</option><option>CHHOTIGWALTOLI</option><option>DWARKAPURI</option>
                            <option>GANDHI NAGAR</option><option>GOUTAMPURA</option><option>HATOD</option>
                            <option>HERA NAGAR</option><option>JUNI INDORE</option><option>KANADIYA</option>
                            <option>KHAJRANA</option><option>KHUDEL</option><option>KISHANGANJ</option>
                            <option>KSHIPRA</option><option>LASUDIYA</option><option>M.G.ROAD</option>
                            <option>MAHILA THANA</option><option>MALHARGANJ</option><option>MANPUR</option>
                            <option>MHOW</option><option>PALASIA</option><option>VIJAY NAGAR</option>
                        </select>
                    </div>
                </div>
                <div class="form-group" style="margin-top: 2rem;">
                    <label>Factual Description (Minimum 30 words)</label>
                    <textarea name="description" class="form-control" rows="6" placeholder="Document the sequence of events with clarity..." required></textarea>
                </div>
                <div style="text-align: right; margin-top: 4rem;">
                    <button type="button" class="btn btn-primary" onclick="nextStep(2)" style="min-width: 200px;">
                        Proceed to Suspect <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>

            <!-- Step 2: Accused Details -->
            <div class="step-content" id="step2">
                 <div style="margin-bottom: 3rem;">
                    <h2 style="font-size: 2.5rem; margin-bottom: 0.5rem;"><i class="fas fa-user-secret" style="color: var(--neon-purple);"></i> Suspect Profile</h2>
                    <p style="color: var(--text-muted);">Detail any known information about the individuals involved.</p>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div class="form-group">
                        <label>Full Name / Alias</label>
                        <input type="text" name="accusedName" class="form-control" placeholder="Leave blank if unknown">
                    </div>
                    <div class="form-group">
                        <label>Distinguishing Marks</label>
                        <input type="text" name="accusedIdentification" class="form-control" placeholder="Tattoos, scars, gait, etc.">
                    </div>
                </div>
                <div class="form-group" style="margin-top: 1rem;">
                    <label>Last Known Coordinates / Address</label>
                    <input type="text" name="accusedAddress" class="form-control" placeholder="Location where suspect was last sighted">
                </div>
                <div class="form-group" style="margin-top: 2rem;">
                    <label>Behavioral & Physical Profile</label>
                    <textarea name="accusedDescription" class="form-control" rows="4" placeholder="Height, build, attire, speech patterns, etc."></textarea>
                </div>
                <div style="display: flex; justify-content: space-between; margin-top: 4rem;">
                    <button type="button" class="btn btn-outline" onclick="nextStep(1)">
                        <i class="fas fa-chevron-left"></i> Background
                    </button>
                    <button type="button" class="btn btn-primary" onclick="nextStep(3)" style="min-width: 200px;">
                        Proceed to Evidence <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>

            <!-- Step 3: Evidence -->
            <div class="step-content" id="step3">
                <div style="margin-bottom: 3rem;">
                    <h2 style="font-size: 2.5rem; margin-bottom: 0.5rem;"><i class="fas fa-fingerprint" style="color: var(--accent);"></i> Evidence Vault</h2>
                    <p style="color: var(--text-muted);">Securely upload relevant digital assets (Max 50MB per file).</p>
                </div>

                <div class="file-upload-wrapper" id="dropZone" onclick="document.getElementById('evidenceInput').click()">
                    <i class="fas fa-cloud-arrow-up"></i>
                    <h3>Drag & Drop Assets</h3>
                    <p style="color: var(--text-muted); font-size: 0.9rem;">Supporting Images (JPG/PNG) & Video (MP4)</p>
                    <input type="file" name="evidenceFiles" id="evidenceInput" style="display: none;" multiple accept="image/*,video/mp4" onchange="handleFileSelect(event)">
                </div>

                <div id="previewArea" class="image-preview-grid" style="margin-top: 2rem;"></div>

                <div style="background: rgba(245, 158, 11, 0.05); padding: 2rem; border-radius: 24px; margin-top: 4rem; border: 1px solid rgba(245, 158, 11, 0.2); color: #fbbf24; display: flex; gap: 1.5rem; align-items: flex-start;">
                    <i class="fas fa-shield-halved" style="font-size: 2rem; margin-top: 0.2rem;"></i>
                    <p style="font-size: 0.95rem; line-height: 1.6;">
                        <strong>Legal Disclaimer:</strong> You are submitting an official government record. Falsifying information or evidence is a criminal offense subject to prosecution under applicable laws. Data is encrypted and logged.
                    </p>
                </div>

                <div style="display: flex; justify-content: space-between; margin-top: 4rem;">
                    <button type="button" class="btn btn-outline" onclick="nextStep(2)">
                        <i class="fas fa-chevron-left"></i> Suspect Info
                    </button>
                    <button type="submit" class="btn btn-accent" style="min-width: 250px;">
                        Transmit FIR <i class="fas fa-satellite-dish" style="margin-left: 0.75rem;"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
</main>

<% String firNumber = (String) request.getAttribute("firNumber");
   if (firNumber != null) { %>
<div style="position: fixed; inset: 0; background: rgba(2, 6, 23, 0.95); backdrop-filter: blur(20px); display: flex; align-items: center; justify-content: center; z-index: 2000; animation: fadeIn 0.4s;">
    <div class="form-container" style="max-width: 600px; text-align: center; border: 1px solid var(--neon-blue); box-shadow: 0 0 50px rgba(0, 242, 255, 0.2);">
        <div style="width: 120px; height: 120px; background: rgba(16, 185, 129, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 2.5rem; border: 2px solid var(--success);">
            <i class="fas fa-check" style="font-size: 4rem; color: var(--success);"></i>
        </div>
        <h2 style="font-size: 2.5rem; margin-bottom: 1rem;">System Registered</h2>
        <p style="color: var(--text-muted); margin-bottom: 3rem;">Operational FIR Number Generated:</p>
        <div style="background: rgba(0, 242, 255, 0.05); color: var(--neon-blue); padding: 2rem; border-radius: 20px; font-size: 3rem; font-weight: 800; margin: 2rem 0; letter-spacing: 5px; border: 1px solid rgba(0, 242, 255, 0.3); text-shadow: 0 0 15px rgba(0, 242, 255, 0.5);">
            <%= firNumber %>
        </div>
        <div style="display: flex; gap: 1.5rem; margin-top: 3rem;">
            <button class="btn btn-outline" style="flex: 1;" onclick="copyID('<%= firNumber %>')"><i class="fas fa-copy"></i> Copy ID</button>
            <a href="TrackFIRServlet" class="btn btn-primary" style="flex: 1;">Track Status <i class="fas fa-radar"></i></a>
        </div>
    </div>
</div>
<% } %>

<script>
    function nextStep(step) {
        document.querySelectorAll('.step-content').forEach(el => el.classList.remove('active'));
        document.querySelectorAll('.step').forEach(el => el.classList.remove('active'));
        
        document.getElementById('step' + step).classList.add('active');
        for(let i=1; i<=step; i++) {
            document.getElementById('s' + i).classList.add('active');
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function handleFileSelect(e) {
        const files = e.target.files;
        const preview = document.getElementById('previewArea');
        preview.innerHTML = '';
        
        for (let file of files) {
            const reader = new FileReader();
            const div = document.createElement('div');
            div.className = 'preview-item glass';
            div.style.height = '120px';
            div.style.borderRadius = '16px';
            div.style.overflow = 'hidden';
            div.style.border = '1px solid var(--glass-border)';
            
            reader.onload = function(event) {
                if (file.type.startsWith('image/')) {
                    div.innerHTML = `<img src="${event.target.result}" style="width:100%; height:100%; object-fit:cover;">`;
                } else {
                    div.innerHTML = `<div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:#000;"><i class="fas fa-video" style="color:white;"></i></div>`;
                }
            }
            reader.readAsDataURL(file);
            preview.appendChild(div);
        }
    }

    // Drag and Drop Logic
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('evidenceInput');

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) { e.preventDefault(); e.stopPropagation(); }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.style.borderColor = 'var(--neon-blue)', false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.style.borderColor = 'var(--glass-border)', false);
    });

    dropZone.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        fileInput.files = files;
        handleFileSelect({ target: { files: files } });
    }

    function copyID(id) {
        navigator.clipboard.writeText(id);
        const btn = event.target;
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-check"></i> Copied!';
        setTimeout(() => btn.innerHTML = originalText, 2000);
    }
</script>

</body>
</html>