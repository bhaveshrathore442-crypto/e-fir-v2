package com.efir.model;

import java.sql.Date;
import java.sql.Timestamp;

public class FIR {
    private int firId;
    private int userId;
    private String incidentType;
    private Date incidentDate;
    private String incidentLocation;
    private String description;
    private String status;
    private Timestamp createdAt;
    private String firNumber;
    private String accusedName;
    private String accusedDescription;
    private String accusedAddress;
    private String accusedIdentification;
    private byte[] imageData;
    private String policeStation;
    private String policeOfficerName;
    private String progressStatus;
    private String progressDescription;
    private int assignedPoliceId;
    private String mediaPaths;

    // Getters and Setters
    public int getFirId() { return firId; }
    public void setFirId(int firId) { this.firId = firId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getIncidentType() { return incidentType; }
    public void setIncidentType(String incidentType) { this.incidentType = incidentType; }

    public Date getIncidentDate() { return incidentDate; }
    public void setIncidentDate(Date incidentDate) { this.incidentDate = incidentDate; }

    public String getIncidentLocation() { return incidentLocation; }
    public void setIncidentLocation(String incidentLocation) { this.incidentLocation = incidentLocation; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getFirNumber() { return firNumber; }
    public void setFirNumber(String fir_number) { this.firNumber = fir_number; }

    public String getAccusedName() { return accusedName; }
    public void setAccusedName(String accusedName) { this.accusedName = accusedName; }

    public String getAccusedDescription() { return accusedDescription; }
    public void setAccusedDescription(String accusedDescription) { this.accusedDescription = accusedDescription; }

    public String getAccusedAddress() { return accusedAddress; }
    public void setAccusedAddress(String accusedAddress) { this.accusedAddress = accusedAddress; }

    public String getAccusedIdentification() { return accusedIdentification; }
    public void setAccusedIdentification(String accusedIdentification) { this.accusedIdentification = accusedIdentification; }

    public byte[] getImageData() { return imageData; }
    public void setImageData(byte[] imageData) { this.imageData = imageData; }

    public String getPoliceStation() { return policeStation; }
    public void setPoliceStation(String policeStation) { this.policeStation = policeStation; }

    public String getPoliceOfficerName() { return policeOfficerName; }
    public void setPoliceOfficerName(String policeOfficerName) { this.policeOfficerName = policeOfficerName; }

    public String getProgressStatus() { return progressStatus; }
    public void setProgressStatus(String progressStatus) { this.progressStatus = progressStatus; }

    public String getProgressDescription() { return progressDescription; }
    public void setProgressDescription(String progressDescription) { this.progressDescription = progressDescription; }

    public int getAssignedPoliceId() { return assignedPoliceId; }
    public void setAssignedPoliceId(int assignedPoliceId) { this.assignedPoliceId = assignedPoliceId; }

    public String getMediaPaths() { return mediaPaths; }
    public void setMediaPaths(String mediaPaths) { this.mediaPaths = mediaPaths; }
}
