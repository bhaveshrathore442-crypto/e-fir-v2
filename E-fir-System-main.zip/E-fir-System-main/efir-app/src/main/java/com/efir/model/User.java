package com.efir.model;

public class User {
    private int userId;
    private String fullName;
    private String email;
    private String password;
    private String role;
    private String aadhaarNo;
    private String phone;
    private String address;
    private String policeIdCardNumber;
    private String authoritativeId;

    // Getters and Setters
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getAadhaarNo() { return aadhaarNo; }
    public void setAadhaarNo(String aadhaarNo) { this.aadhaarNo = aadhaarNo; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getPoliceIdCardNumber() { return policeIdCardNumber; }
    public void setPoliceIdCardNumber(String policeIdCardNumber) { this.policeIdCardNumber = policeIdCardNumber; }

    public String getAuthoritativeId() { return authoritativeId; }
    public void setAuthoritativeId(String authoritativeId) { this.authoritativeId = authoritativeId; }
}
