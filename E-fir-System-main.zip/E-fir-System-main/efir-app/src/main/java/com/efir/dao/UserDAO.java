package com.efir.dao;

import com.efir.model.User;
import com.efir.util.DBConnection;
import java.sql.*;

public class UserDAO {

    // Register a new user
    public boolean registerUser(User user) throws SQLException {
        String sql = "INSERT INTO users (full_name, email, password, role, aadhaar_no, phone, address, police_id_card_number, authoritative_id) VALUES (?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getFullName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getRole());
            ps.setString(5, user.getAadhaarNo());
            ps.setString(6, user.getPhone());
            ps.setString(7, user.getAddress());
            ps.setString(8, user.getPoliceIdCardNumber());
            ps.setString(9, user.getAuthoritativeId());
            return ps.executeUpdate() > 0;
        }
    }

    // Login - find user by email and password
    public User loginUser(String email, String password) throws SQLException {
        String sql = "SELECT * FROM users WHERE email=? AND password=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setFullName(rs.getString("full_name"));
                user.setEmail(rs.getString("email"));
                user.setRole(rs.getString("role"));
                user.setAadhaarNo(rs.getString("aadhaar_no"));
                user.setPhone(rs.getString("phone"));
                user.setAddress(rs.getString("address"));
                user.setPoliceIdCardNumber(rs.getString("police_id_card_number"));
                user.setAuthoritativeId(rs.getString("authoritative_id"));
                return user;
            }
        }
        return null;
    }

    // Get all police officers with case counts
    public java.util.List<User> getOfficersWithStats() throws SQLException {
        java.util.List<User> list = new java.util.ArrayList<>();
        String sql = "SELECT u.*, COUNT(f.fir_id) as case_count FROM users u " +
                     "LEFT JOIN fir_reports f ON u.user_id = f.assigned_police_id " +
                     "WHERE u.role = 'police' " +
                     "GROUP BY u.user_id";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setFullName(rs.getString("full_name"));
                user.setEmail(rs.getString("email"));
                user.setPoliceIdCardNumber(rs.getString("police_id_card_number"));
                // We use authoritative_id to temporarily store case count or add a field to User model
                // But since I can't easily change User model without checking it, I'll use authoritativeId
                user.setAuthoritativeId(String.valueOf(rs.getInt("case_count")));
                list.add(user);
            }
        }
        return list;
    }

    public java.util.List<User> getOfficers() throws SQLException {
        return getOfficersWithStats();
    }
}
