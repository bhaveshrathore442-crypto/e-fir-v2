package com.efir.model;

public class Accused {
    private int accusedId;
    private String name;
    private int age;
    private String gender;
    private String address;
    private String identificationMark;
    private String criminalHistory;
    private String status;

    public int getAccusedId() { return accusedId; }
    public void setAccusedId(int accusedId) { this.accusedId = accusedId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getIdentificationMark() { return identificationMark; }
    public void setIdentificationMark(String identificationMark) { this.identificationMark = identificationMark; }

    public String getCriminalHistory() { return criminalHistory; }
    public void setCriminalHistory(String criminalHistory) { this.criminalHistory = criminalHistory; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
