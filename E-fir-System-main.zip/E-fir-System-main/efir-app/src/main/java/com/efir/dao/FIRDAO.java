package com.efir.dao;

import com.efir.model.FIR;
import com.efir.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FIRDAO {

    // File a new FIR
    public boolean fileFIR(FIR fir) throws SQLException {
        String sql = "INSERT INTO fir_reports (user_id, incident_type, incident_date, incident_location, description, accused_name, accused_description, accused_address, accused_identification, image_data, police_station, media_paths) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) RETURNING fir_id";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, fir.getUserId());
            ps.setString(2, fir.getIncidentType());
            ps.setDate(3, fir.getIncidentDate());
            ps.setString(4, fir.getIncidentLocation());
            ps.setString(5, fir.getDescription());
            ps.setString(6, fir.getAccusedName());
            ps.setString(7, fir.getAccusedDescription());
            ps.setString(8, fir.getAccusedAddress());
            ps.setString(9, fir.getAccusedIdentification());
            ps.setBytes(10, fir.getImageData());
            ps.setString(11, fir.getPoliceStation());
            ps.setString(12, fir.getMediaPaths());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int id = rs.getInt(1);
                    fir.setFirId(id);
                    String year = String.valueOf(java.time.LocalDate.now().getYear());
                    String firNumber = "FIR-" + year + "-" + String.format("%04d", id);
                    fir.setFirNumber(firNumber);

                    // Update the record with fir_number
                    String updateSql = "UPDATE fir_reports SET fir_number = ? WHERE fir_id = ?";
                    try (PreparedStatement psUpdate = conn.prepareStatement(updateSql)) {
                        psUpdate.setString(1, firNumber);
                        psUpdate.setInt(2, id);
                        psUpdate.executeUpdate();
                    }
                    return true;
                }
            }
        }
        return false;
    }

    // Track FIR by ID
    public FIR getFIRById(int firId) throws SQLException {
        String sql = "SELECT f.*, u.full_name as police_officer_name FROM fir_reports f " +
                     "LEFT JOIN users u ON f.assigned_police_id = u.user_id WHERE f.fir_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, firId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapResultSetToFIR(rs);
            }
        }
        return null;
    }

    public FIR getFIRByNumber(String firNumber) throws SQLException {
        String sql = "SELECT f.*, u.full_name as police_officer_name FROM fir_reports f " +
                     "LEFT JOIN users u ON f.assigned_police_id = u.user_id WHERE f.fir_number=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, firNumber);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToFIR(rs);
                }
            }
        }
        return null;
    }

    // Get FIRs by User ID (for personal tracking)
    public List<FIR> getFIRsByUserId(int userId) throws SQLException {
        List<FIR> list = new ArrayList<>();
        String sql = "SELECT f.*, u.full_name as police_officer_name FROM fir_reports f " +
                     "LEFT JOIN users u ON f.assigned_police_id = u.user_id " +
                     "WHERE f.user_id = ? ORDER BY f.created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToFIR(rs));
                }
            }
        }
        return list;
    }

    // Get all FIRs (for admin/police dashboard)
    public List<FIR> getAllFIRs() throws SQLException {
        List<FIR> list = new ArrayList<>();
        String sql = "SELECT f.*, u.full_name as police_officer_name FROM fir_reports f " +
                     "LEFT JOIN users u ON f.assigned_police_id = u.user_id " +
                     "ORDER BY f.created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToFIR(rs));
            }
        }
        return list;
    }

    private FIR mapResultSetToFIR(ResultSet rs) throws SQLException {
        FIR fir = new FIR();
        fir.setFirId(rs.getInt("fir_id"));
        fir.setUserId(rs.getInt("user_id"));
        fir.setIncidentType(rs.getString("incident_type"));
        fir.setIncidentDate(rs.getDate("incident_date"));
        fir.setIncidentLocation(rs.getString("incident_location"));
        fir.setDescription(rs.getString("description"));
        fir.setStatus(rs.getString("status"));
        fir.setCreatedAt(rs.getTimestamp("created_at"));
        fir.setFirNumber(rs.getString("fir_number"));
        fir.setAccusedName(rs.getString("accused_name"));
        fir.setAccusedDescription(rs.getString("accused_description"));
        fir.setAccusedAddress(rs.getString("accused_address"));
        fir.setAccusedIdentification(rs.getString("accused_identification"));
        fir.setImageData(rs.getBytes("image_data"));
        fir.setPoliceStation(rs.getString("police_station"));
        fir.setPoliceOfficerName(rs.getString("police_officer_name"));
        fir.setProgressStatus(rs.getString("progress_status"));
        fir.setProgressDescription(rs.getString("progress_description"));
        fir.setAssignedPoliceId(rs.getInt("assigned_police_id"));
        fir.setMediaPaths(rs.getString("media_paths"));
        return fir;
    }

    // Update FIR status (admin/police)
    public boolean updateStatus(int firId, String status, String remarks, int updatedBy) throws SQLException {
        String updateFIR = "UPDATE fir_reports SET status=? WHERE fir_id=?";
        // Insert into legacy status_updates
        String insertLog = "INSERT INTO status_updates (fir_id, updated_by, status, remarks) VALUES (?,?,?,?)";
        // Insert into new case_updates for timeline
        String insertTimeline = "INSERT INTO case_updates (fir_id, police_id, update_text, status_at_time) VALUES (?,?,?,?)";
        
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps1 = conn.prepareStatement(updateFIR);
                 PreparedStatement ps2 = conn.prepareStatement(insertLog);
                 PreparedStatement ps3 = conn.prepareStatement(insertTimeline)) {
                ps1.setString(1, status);
                ps1.setInt(2, firId);
                ps1.executeUpdate();
                
                ps2.setInt(1, firId);
                ps2.setInt(2, updatedBy);
                ps2.setString(3, status);
                ps2.setString(4, remarks);
                ps2.executeUpdate();

                ps3.setInt(1, firId);
                ps3.setInt(2, updatedBy);
                ps3.setString(3, remarks);
                ps3.setString(4, status);
                ps3.executeUpdate();

                conn.commit();
                return true;
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        }
    }

    public boolean assignPolice(int firId, int policeId) throws SQLException {
        String sql = "UPDATE fir_reports SET assigned_police_id = ? WHERE fir_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, policeId);
            ps.setInt(2, firId);
            return ps.executeUpdate() > 0;
        }
    }

    public List<FIR> getFIRsByOfficerId(int officerId) throws SQLException {
        List<FIR> list = new ArrayList<>();
        String sql = "SELECT f.*, u.full_name as police_officer_name FROM fir_reports f " +
                     "LEFT JOIN users u ON f.assigned_police_id = u.user_id " +
                     "WHERE f.assigned_police_id = ? ORDER BY f.created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, officerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToFIR(rs));
                }
            }
        }
        return list;
    }

    public java.util.Map<String, Integer> getStats() throws SQLException {
        java.util.Map<String, Integer> stats = new java.util.HashMap<>();
        String sql = "SELECT status, count(*) FROM fir_reports GROUP BY status";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            int total = 0;
            while (rs.next()) {
                String status = rs.getString(1);
                int count = rs.getInt(2);
                stats.put(status, count);
                total += count;
            }
            stats.put("Total", total);
        }
        return stats;
    }
}
