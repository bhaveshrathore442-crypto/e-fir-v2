package com.efir.controller;

import com.efir.dao.FIRDAO;
import com.efir.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/UpdateStatusServlet")
public class UpdateStatusServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        // Check session and role
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String role = (String) session.getAttribute("userRole");
        if (!role.equals("admin") && !role.equals("police")) {
            response.sendRedirect("file-fir.jsp");
            return;
        }

        String firIdStr = request.getParameter("firId");
        String status   = request.getParameter("status");
        String remarks  = request.getParameter("remarks");
        User loggedUser = (User) session.getAttribute("user");

        if (firIdStr == null || status == null || status.isEmpty()) {
            response.sendRedirect("AdminDashboardServlet");
            return;
        }

        try {
            int firId = Integer.parseInt(firIdStr.trim());
            FIRDAO dao = new FIRDAO();
            dao.updateStatus(firId, status, remarks, loggedUser.getUserId());
        } catch (Exception e) {
            // log error silently and redirect back
        }

        response.sendRedirect("AdminDashboardServlet");
    }
}
