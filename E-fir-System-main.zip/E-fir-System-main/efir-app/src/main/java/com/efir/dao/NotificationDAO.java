package com.efir.dao;

import com.efir.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotificationDAO {

    public void addNotification(String message, String roleTarget) throws SQLException {
        String sql = "INSERT INTO notifications (message, role_target) VALUES (?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, message);
            ps.setString(2, roleTarget);
            ps.executeUpdate();
        }
    }

    public List<String> getUnreadNotifications(String roleTarget) throws SQLException {
        List<String> list = new ArrayList<>();
        String sql = "SELECT message FROM notifications WHERE role_target = ? AND is_read = FALSE ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, roleTarget);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(rs.getString("message"));
                }
            }
        }
        return list;
    }

    public void markAsRead(String roleTarget) throws SQLException {
        String sql = "UPDATE notifications SET is_read = TRUE WHERE role_target = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, roleTarget);
            ps.executeUpdate();
        }
    }
}
