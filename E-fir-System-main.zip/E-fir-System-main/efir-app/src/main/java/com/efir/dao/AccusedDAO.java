package com.efir.dao;

import com.efir.model.Accused;
import com.efir.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccusedDAO {

    public List<Accused> getAllAccused() throws SQLException {
        List<Accused> list = new ArrayList<>();
        String sql = "SELECT * FROM accused_details";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToAccused(rs));
            }
        }
        return list;
    }

    private Accused mapResultSetToAccused(ResultSet rs) throws SQLException {
        Accused a = new Accused();
        a.setAccusedId(rs.getInt("accused_id"));
        a.setName(rs.getString("name"));
        a.setAge(rs.getInt("age"));
        a.setGender(rs.getString("gender"));
        a.setAddress(rs.getString("address"));
        a.setIdentificationMark(rs.getString("identification_mark"));
        a.setCriminalHistory(rs.getString("criminal_history"));
        a.setStatus(rs.getString("status"));
        return a;
    }
}
