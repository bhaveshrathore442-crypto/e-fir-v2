package com.efir.controller;

import com.efir.dao.FIRDAO;
import com.efir.model.FIR;
import com.efir.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;

@WebServlet("/FileFIRServlet")
@MultipartConfig(maxFileSize = 1024 * 1024 * 5) // 5MB limit
public class FileFIRServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Check session
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp?redirect=file-fir.jsp");
            return;
        }
        request.getRequestDispatcher("file-fir.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        // Check session
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp?redirect=file-fir.jsp");
            return;
        }

        User loggedUser = (User) session.getAttribute("user");

        String incidentType     = request.getParameter("incidentType").trim();
        String incidentDateStr  = request.getParameter("incidentDate").trim();
        String incidentLocation = request.getParameter("incidentLocation").trim();
        String description      = request.getParameter("description").trim();
        String policeStation    = request.getParameter("policeStation").trim();
        
        // New Accused details
        String accusedName           = request.getParameter("accusedName");
        String accusedDescription    = request.getParameter("accusedDescription");
        String accusedAddress        = request.getParameter("accusedAddress");
        String accusedIdentification = request.getParameter("accusedIdentification");

        if (incidentType.isEmpty() || incidentDateStr.isEmpty()
                || incidentLocation.isEmpty() || description.isEmpty() || policeStation.isEmpty()) {
            request.setAttribute("error", "All fields are required including Police Station.");
            request.getRequestDispatcher("file-fir.jsp").forward(request, response);
            return;
        }

        if (description.length() < 30) {
            request.setAttribute("error", "Description must be at least 30 characters.");
            request.getRequestDispatcher("file-fir.jsp").forward(request, response);
            return;
        }

        FIR fir = new FIR();
        fir.setUserId(loggedUser.getUserId());
        fir.setIncidentType(incidentType);
        fir.setIncidentDate(Date.valueOf(incidentDateStr));
        fir.setIncidentLocation(incidentLocation);
        fir.setDescription(description);
        fir.setAccusedName(accusedName);
        fir.setAccusedDescription(accusedDescription);
        fir.setAccusedAddress(accusedAddress);
        fir.setAccusedIdentification(accusedIdentification);
        fir.setPoliceStation(policeStation);

        // Handle Multi-Part Evidence Upload
        java.util.Collection<Part> parts = request.getParts();
        StringBuilder mediaPaths = new StringBuilder();
        boolean firstFile = true;
        
        for (Part part : parts) {
            if (part.getName().equals("evidenceFiles") && part.getSize() > 0) {
                if (firstFile) {
                    // Store the first file as the main image blob
                    InputStream inputStream = part.getInputStream();
                    fir.setImageData(inputStream.readAllBytes());
                    mediaPaths.append(part.getSubmittedFileName());
                    firstFile = false;
                } else {
                    // Append subsequent filenames
                    mediaPaths.append(", ").append(part.getSubmittedFileName());
                }
            }
        }
        fir.setMediaPaths(mediaPaths.toString());

        try {
            FIRDAO dao = new FIRDAO();
            com.efir.dao.NotificationDAO notifDAO = new com.efir.dao.NotificationDAO();
            boolean success = dao.fileFIR(fir);
            if (success) {
                // Add notification for admin
                notifDAO.addNotification("New FIR Registered: " + fir.getFirNumber() + " (" + fir.getIncidentType() + ")", "admin");
                
                request.setAttribute("success", "Your FIR has been successfully registered.");
                request.setAttribute("firNumber", fir.getFirNumber());
                request.getRequestDispatcher("file-fir.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Failed to file FIR. Please try again.");
                request.getRequestDispatcher("file-fir.jsp").forward(request, response);
            }
        } catch (Exception e) {
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("file-fir.jsp").forward(request, response);
        }
    }
}
