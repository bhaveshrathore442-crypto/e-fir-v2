package com.efir.controller;

import com.efir.dao.UserDAO;
import com.efir.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String email    = request.getParameter("email").trim();
        String password = request.getParameter("password").trim();
        String role     = request.getParameter("role").trim();

        if (email.isEmpty() || password.isEmpty() || role.isEmpty()) {
            request.setAttribute("error", "All fields are required.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        try {
            UserDAO dao = new UserDAO();
            User user = dao.loginUser(email, password);

            if (user == null) {
                request.setAttribute("error", "Invalid email or password.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
                return;
            }

            if (!user.getRole().equals(role)) {
                request.setAttribute("error", "Role does not match. Please select correct role.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
                return;
            }

            // Create session
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            session.setAttribute("userId", user.getUserId());
            session.setAttribute("userName", user.getFullName());
            session.setAttribute("userRole", user.getRole());
            session.setMaxInactiveInterval(30 * 60); // 30 minutes

            // Redirect based on role or requested page
            String redirect = request.getParameter("redirect");
            if (redirect != null && !redirect.trim().isEmpty()) {
                response.sendRedirect(redirect);
            } else if (user.getRole().equals("admin") || user.getRole().equals("police")) {
                response.sendRedirect("AdminDashboardServlet");
            } else {
                response.sendRedirect("file-fir.jsp");
            }

        } catch (Exception e) {
            request.setAttribute("error", "Login error: " + e.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
