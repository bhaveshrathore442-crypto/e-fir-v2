package com.efir.controller;

import com.efir.dao.AccusedDAO;
import com.efir.model.Accused;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/AccusedListServlet")
public class AccusedListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            AccusedDAO dao = new AccusedDAO();
            List<Accused> list = dao.getAllAccused();
            request.setAttribute("accusedList", list);
            request.getRequestDispatcher("accused-list.jsp").forward(request, response);
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }
}
