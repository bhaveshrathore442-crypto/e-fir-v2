package com.efir.model;

import java.sql.Timestamp;

public class CaseUpdate {
    private int updateId;
    private int firId;
    private int policeId;
    private String updateText;
    private String statusAtTime;
    private Timestamp createdAt;
    private String policeName; // Joined for convenience

    // Getters and Setters
    public int getUpdateId() { return updateId; }
    public void setUpdateId(int updateId) { this.updateId = updateId; }

    public int getFirId() { return firId; }
    public void setFirId(int firId) { this.firId = firId; }

    public int getPoliceId() { return policeId; }
    public void setPoliceId(int policeId) { this.policeId = policeId; }

    public String getUpdateText() { return updateText; }
    public void setUpdateText(String updateText) { this.updateText = updateText; }

    public String getStatusAtTime() { return statusAtTime; }
    public void setStatusAtTime(String statusAtTime) { this.statusAtTime = statusAtTime; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getPoliceName() { return policeName; }
    public void setPoliceName(String policeName) { this.policeName = policeName; }
}
