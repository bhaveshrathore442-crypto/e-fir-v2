package com.efir.controller;

import com.efir.dao.UserDAO;
import com.efir.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String fullName   = request.getParameter("fullName").trim();
        String email      = request.getParameter("email").trim();
        String password   = request.getParameter("password").trim();
        String role       = request.getParameter("role").trim();
        String aadhaarNo  = request.getParameter("aadhaarNo").trim();
        String phone      = request.getParameter("phone").trim();
        String address    = request.getParameter("address") != null ? request.getParameter("address").trim() : "";
        String policeIdCardNumber = request.getParameter("policeIdCardNumber") != null ? request.getParameter("policeIdCardNumber").trim() : "";
        String authoritativeId    = request.getParameter("authoritativeId") != null ? request.getParameter("authoritativeId").trim() : "";

        // Convert empty strings to null for unique database columns to avoid duplicate key conflicts
        if (policeIdCardNumber.isEmpty()) policeIdCardNumber = null;
        if (authoritativeId.isEmpty()) authoritativeId = null;

        // Basic validation
        if (fullName.isEmpty() || email.isEmpty() || password.isEmpty()
                || role.isEmpty() || aadhaarNo.isEmpty() || phone.isEmpty()) {
            request.setAttribute("error", "All required fields must be filled.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        if (!aadhaarNo.matches("^[0-9]{12}$")) {
            request.setAttribute("error", "Aadhaar number must be exactly 12 digits.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        if (!phone.matches("^[0-9]{10}$")) {
            request.setAttribute("error", "Phone number must be exactly 10 digits.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        User user = new User();
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role);
        user.setAadhaarNo(aadhaarNo);
        user.setPhone(phone);
        user.setAddress(address);
        user.setPoliceIdCardNumber(policeIdCardNumber);
        user.setAuthoritativeId(authoritativeId);

        try {
            UserDAO dao = new UserDAO();
            boolean success = dao.registerUser(user);
            if (success) {
                request.setAttribute("success", "Account created successfully! Please login.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Registration failed. Please try again.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
            }
        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg != null && msg.contains("duplicate key")) {
                if (msg.contains("email")) {
                    request.setAttribute("error", "Email already registered. Please use a different email.");
                } else if (msg.contains("aadhaar_no")) {
                    request.setAttribute("error", "Aadhaar number already registered. Please check the number.");
                } else if (msg.contains("phone")) {
                    request.setAttribute("error", "Phone number already registered. Please use a different number.");
                } else if (msg.contains("police_id_card_number") || msg.contains("authoritative_id")) {
                    request.setAttribute("error", "Official ID already registered. Please verify your credentials.");
                } else {
                    request.setAttribute("error", "Information already registered. Please use different details.");
                }
            } else {
                request.setAttribute("error", "Database error: " + e.getMessage());
            }
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }
}
