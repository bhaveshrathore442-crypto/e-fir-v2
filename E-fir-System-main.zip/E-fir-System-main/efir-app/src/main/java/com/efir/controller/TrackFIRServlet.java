package com.efir.controller;

import com.efir.dao.FIRDAO;
import com.efir.model.FIR;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/TrackFIRServlet")
public class TrackFIRServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp?error=Please login to track FIR&redirect=TrackFIRServlet");
            return;
        }

        com.efir.model.User loggedUser = (com.efir.model.User) session.getAttribute("user");
        try {
            FIRDAO dao = new FIRDAO();
            request.setAttribute("userFIRs", dao.getFIRsByUserId(loggedUser.getUserId()));
        } catch (Exception e) {
            request.setAttribute("error", "Error fetching your FIRs: " + e.getMessage());
        }
        request.getRequestDispatcher("track-fir.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp?error=Please login to track FIR&redirect=TrackFIRServlet");
            return;
        }

        com.efir.model.User loggedUser = (com.efir.model.User) session.getAttribute("user");
        String firIdStr = request.getParameter("firId");

        try {
            FIRDAO dao = new FIRDAO();
            // Always reload the list of user's FIRs
            request.setAttribute("userFIRs", dao.getFIRsByUserId(loggedUser.getUserId()));

            if (firIdStr != null && !firIdStr.trim().isEmpty()) {
                FIR fir = null;
                if (firIdStr.trim().toUpperCase().startsWith("FIR-")) {
                    fir = dao.getFIRByNumber(firIdStr.trim().toUpperCase());
                } else {
                    try {
                        int firId = Integer.parseInt(firIdStr.trim());
                        fir = dao.getFIRById(firId);
                    } catch (NumberFormatException e) {
                        request.setAttribute("notFound", "Invalid format. Enter numeric ID or FIR-YYYY-XXXX.");
                    }
                }

                if (fir != null) {
                    boolean isAuthorized = (fir.getUserId() == loggedUser.getUserId()) 
                                        || "admin".equals(loggedUser.getRole()) 
                                        || "police".equals(loggedUser.getRole());
                    
                    if (isAuthorized) {
                        request.setAttribute("fir", fir);
                        com.efir.dao.CaseUpdateDAO updatesDAO = new com.efir.dao.CaseUpdateDAO();
                        request.setAttribute("caseUpdates", updatesDAO.getUpdatesByFIRId(fir.getFirId()));
                    } else {
                        request.setAttribute("error", "You are not authorized to view this FIR");
                    }
                } else if (request.getAttribute("notFound") == null) {
                    request.setAttribute("notFound", "No FIR found with ID/Number: " + firIdStr);
                }
            }
        } catch (Exception e) {
            request.setAttribute("error", "System error: " + e.getMessage());
        }

        request.getRequestDispatcher("track-fir.jsp").forward(request, response);
    }
}
