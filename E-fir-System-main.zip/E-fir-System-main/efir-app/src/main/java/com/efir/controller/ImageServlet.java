package com.efir.controller;

import com.efir.dao.FIRDAO;
import com.efir.model.FIR;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;

@WebServlet("/ImageServlet")
public class ImageServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String firIdStr = request.getParameter("firId");
        if (firIdStr != null) {
            try {
                int firId = Integer.parseInt(firIdStr);
                FIRDAO dao = new FIRDAO();
                FIR fir = dao.getFIRById(firId);
                if (fir != null && fir.getImageData() != null) {
                    response.setContentType("image/png"); // or detect type if possible
                    OutputStream out = response.getOutputStream();
                    out.write(fir.getImageData());
                    out.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
