package com.efir.controller;

import com.efir.dao.FIRDAO;
import com.efir.model.FIR;
import com.efir.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/AdminDashboardServlet")
public class AdminDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String role = (String) session.getAttribute("userRole");
        if (!role.equals("admin") && !role.equals("police")) {
            response.sendRedirect("file-fir.jsp");
            return;
        }

        User loggedUser = (User) session.getAttribute("user");

        try {
            FIRDAO dao = new FIRDAO();
            com.efir.dao.UserDAO userDAO = new com.efir.dao.UserDAO();
            com.efir.dao.NotificationDAO notifDAO = new com.efir.dao.NotificationDAO();

            List<FIR> firList;
            if ("police".equals(role)) {
                firList = dao.getFIRsByOfficerId(loggedUser.getUserId());
            } else {
                firList = dao.getAllFIRs();
            }
            request.setAttribute("firList", firList);
            request.setAttribute("stats", dao.getStats());
            request.setAttribute("officers", userDAO.getOfficers());
            request.setAttribute("notifications", notifDAO.getUnreadNotifications("admin"));
        } catch (Exception e) {
            request.setAttribute("error", "Error loading data: " + e.getMessage());
        }

        request.getRequestDispatcher("admin-dashboard.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        if ("assign".equals(action)) {
            int firId = Integer.parseInt(request.getParameter("firId"));
            int policeId = Integer.parseInt(request.getParameter("policeId"));
            
            try {
                FIRDAO dao = new FIRDAO();
                boolean success = dao.assignPolice(firId, policeId);
                if (success) {
                    request.setAttribute("success", "Police officer assigned successfully!");
                } else {
                    request.setAttribute("error", "Failed to assign officer.");
                }
            } catch (Exception e) {
                request.setAttribute("error", "Database error: " + e.getMessage());
            }
        } else if ("addOfficer".equals(action)) {
            String fullName = request.getParameter("fullName");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String policeId = request.getParameter("policeIdCardNumber");
            String aadhaarNo = request.getParameter("aadhaarNo");
            String phone = request.getParameter("phone");

            // Basic validation for existing fields
            if (fullName == null || email == null || password == null || aadhaarNo == null || phone == null) {
                request.setAttribute("error", "All fields are required.");
            } else {
                User newOfficer = new User();
                newOfficer.setFullName(fullName.trim());
                newOfficer.setEmail(email.trim());
                newOfficer.setPassword(password.trim());
                newOfficer.setRole("police");
                newOfficer.setAadhaarNo(aadhaarNo.trim());
                newOfficer.setPhone(phone.trim());
                
                String pId = (policeId != null) ? policeId.trim() : "";
                newOfficer.setPoliceIdCardNumber(pId.isEmpty() ? null : pId);

                try {
                    com.efir.dao.UserDAO dao = new com.efir.dao.UserDAO();
                    if (dao.registerUser(newOfficer)) {
                        request.setAttribute("success", "Police Officer added successfully!");
                    } else {
                        request.setAttribute("error", "Failed to add officer.");
                    }
                } catch (Exception e) {
                    String msg = e.getMessage();
                    if (msg != null && msg.contains("duplicate key")) {
                        if (msg.contains("email")) request.setAttribute("error", "Email already registered.");
                        else if (msg.contains("aadhaar_no")) request.setAttribute("error", "Aadhaar already registered.");
                        else if (msg.contains("phone")) request.setAttribute("error", "Phone already registered.");
                        else if (msg.contains("police_id")) request.setAttribute("error", "Police ID already registered.");
                        else request.setAttribute("error", "Duplicate information found.");
                    } else {
                        request.setAttribute("error", "Registration error: " + e.getMessage());
                    }
                }
            }
        }
        doGet(request, response);
    }
}
