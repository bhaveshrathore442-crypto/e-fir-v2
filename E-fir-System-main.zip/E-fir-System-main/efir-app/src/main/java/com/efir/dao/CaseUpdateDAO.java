package com.efir.dao;

import com.efir.model.CaseUpdate;
import com.efir.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CaseUpdateDAO {

    public List<CaseUpdate> getUpdatesByFIRId(int firId) throws SQLException {
        List<CaseUpdate> list = new ArrayList<>();
        String sql = "SELECT c.*, u.full_name as police_name FROM case_updates c " +
                     "JOIN users u ON c.police_id = u.user_id " +
                     "WHERE c.fir_id = ? ORDER BY c.created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, firId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    CaseUpdate update = new CaseUpdate();
                    update.setUpdateId(rs.getInt("update_id"));
                    update.setFirId(rs.getInt("fir_id"));
                    update.setPoliceId(rs.getInt("police_id"));
                    update.setUpdateText(rs.getString("update_text"));
                    update.setStatusAtTime(rs.getString("status_at_time"));
                    update.setCreatedAt(rs.getTimestamp("created_at"));
                    update.setPoliceName(rs.getString("police_name"));
                    list.add(update);
                }
            }
        }
        return list;
    }

    public boolean addUpdate(CaseUpdate update) throws SQLException {
        String sql = "INSERT INTO case_updates (fir_id, police_id, update_text, status_at_time) VALUES (?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, update.getFirId());
            ps.setInt(2, update.getPoliceId());
            ps.setString(3, update.getUpdateText());
            ps.setString(4, update.getStatusAtTime());
            return ps.executeUpdate() > 0;
        }
    }
}
