@echo off
SETLOCAL EnableDelayedExpansion

:: --- CONFIGURATION ---
SET PROJECT_NAME=EFIR System
SET APP_DIR=efir-app
SET PORT=8080
:: ---------------------

CLS
echo ============================================================
echo   %PROJECT_NAME% - Startup Script
echo ============================================================
echo.

:: Check for Java
java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Java is not installed or not in your PATH.
    echo Please install JDK 17 or higher.
    pause
    exit /b 1
)

:: Check for Maven
call mvn -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Maven is not installed or not in your PATH.
    echo Please install Maven to build and run this project.
    pause
    exit /b 1
)

:: Navigate to app directory
if not exist "%APP_DIR%" (
    echo [ERROR] Directory '%APP_DIR%' not found!
    echo Please run this script from the project root.
    pause
    exit /b 1
)

cd %APP_DIR%

echo [INFO] Building project and starting server...
echo [INFO] Access URL: http://localhost:%PORT%/efir-app/
echo.
echo Press Ctrl+C to stop the server.
echo.

:: Run Maven Jetty Plugin
:: We use clean compile to ensure a fresh build
call mvn clean compile jetty:run

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] The application failed to start.
    echo Please check the logs above for errors.
    pause
)

ENDLOCAL
