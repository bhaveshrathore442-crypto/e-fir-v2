# EFIR - Electronic First Information Report System

## Setup Instructions

### Prerequisites
- Java JDK 17+
- Apache Tomcat 10+
- PostgreSQL 17
- IntelliJ IDEA

### Database Setup
1. Open pgAdmin or psql
2. Create database:
   ```sql
   CREATE DATABASE efir_db;
   ```
3. Import schema and data:
   ```cmd
   psql -U postgres -d efir_db -f database/efir_db.sql
   ```

### Project Setup
1. Clone the repository
2. Open in IntelliJ IDEA
3. Add `lib/postgresql-42.x.x.jar` as a library
4. Configure Tomcat server
5. Run the project

### Login Credentials
| Role | Email | Password |
|------|-------|----------|
| Citizen | rahul@gmail.com | pass1234 |
| Police | ramesh@police.gov.in | officer123 |
| Admin | admin@efir.gov.in | admin@123 |