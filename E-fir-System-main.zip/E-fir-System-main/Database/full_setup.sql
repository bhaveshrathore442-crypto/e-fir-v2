-- Consolidated SQL for E-FIR System
-- Includes Base Schema, Schema Updates, Major Upgrades, and Tracking Details

-- 1. DROP and CREATE TABLES (Clean Start)
DROP TABLE IF EXISTS public.case_updates CASCADE;
DROP TABLE IF EXISTS public.notifications CASCADE;
DROP TABLE IF EXISTS public.status_updates CASCADE;
DROP TABLE IF EXISTS public.evidence CASCADE;
DROP TABLE IF EXISTS public.fir_reports CASCADE;
DROP TABLE IF EXISTS public.police_stations CASCADE;
DROP TABLE IF EXISTS public.accused_details CASCADE;
DROP TABLE IF EXISTS public.users CASCADE;

-- 2. Create users table
CREATE TABLE public.users (
    user_id SERIAL PRIMARY KEY,
    full_name CHARACTER VARYING(100) NOT NULL,
    email CHARACTER VARYING(100) UNIQUE NOT NULL,
    password CHARACTER VARYING(255) NOT NULL,
    aadhaar_no CHARACTER VARYING(12) UNIQUE NOT NULL,
    phone CHARACTER VARYING(10) NOT NULL,
    address TEXT,
    role CHARACTER VARYING(20) NOT NULL CHECK (role IN ('citizen', 'police', 'admin', 'officer')),
    police_id_card_number CHARACTER VARYING(50) UNIQUE,
    authoritative_id CHARACTER VARYING(50) UNIQUE,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Create police_stations table
CREATE TABLE public.police_stations (
    station_id SERIAL PRIMARY KEY,
    station_name CHARACTER VARYING(100) NOT NULL,
    district CHARACTER VARYING(100),
    city CHARACTER VARYING(100),
    state CHARACTER VARYING(100),
    phone CHARACTER VARYING(15),
    address TEXT
);

-- 4. Create fir_reports table
CREATE TABLE public.fir_reports (
    fir_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES public.users(user_id) ON DELETE CASCADE,
    fir_number CHARACTER VARYING(20) UNIQUE,
    incident_type CHARACTER VARYING(100) NOT NULL,
    incident_date DATE NOT NULL,
    incident_location TEXT NOT NULL,
    description TEXT NOT NULL,
    status CHARACTER VARYING(30) DEFAULT 'Pending',
    
    -- Additional fields for tracking and assignment
    police_station CHARACTER VARYING(100),
    assigned_police_id INTEGER REFERENCES public.users(user_id),
    police_officer_name CHARACTER VARYING(100) DEFAULT 'Not Assigned',
    progress_status CHARACTER VARYING(50) DEFAULT '0',
    progress_description TEXT DEFAULT 'FIR has been successfully registered. Waiting for officer assignment.',
    
    -- Evidence and accused info
    accused_name CHARACTER VARYING(255),
    accused_description TEXT,
    accused_address TEXT,
    accused_identification TEXT,
    image_data BYTEA,
    media_paths TEXT,
    
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. Create case_updates table (Timeline)
CREATE TABLE public.case_updates (
    update_id SERIAL PRIMARY KEY,
    fir_id INTEGER REFERENCES public.fir_reports(fir_id) ON DELETE CASCADE,
    police_id INTEGER REFERENCES public.users(user_id),
    update_text TEXT NOT NULL,
    status_at_time CHARACTER VARYING(30),
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 6. Create notifications table
CREATE TABLE public.notifications (
    notification_id SERIAL PRIMARY KEY,
    message TEXT NOT NULL,
    role_target CHARACTER VARYING(20),
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 7. Create accused_details table (Wanted List)
CREATE TABLE public.accused_details (
    accused_id SERIAL PRIMARY KEY,
    name CHARACTER VARYING(255) NOT NULL,
    age INTEGER,
    gender CHARACTER VARYING(20),
    address TEXT,
    identification_mark TEXT,
    criminal_history TEXT,
    status CHARACTER VARYING(50) DEFAULT 'At Large'
);

-- 8. Legacy status_updates table
CREATE TABLE public.status_updates (
    id SERIAL PRIMARY KEY,
    fir_id INTEGER REFERENCES public.fir_reports(fir_id) ON DELETE CASCADE,
    updated_by INTEGER REFERENCES public.users(user_id),
    status CHARACTER VARYING(30),
    remarks TEXT,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. Sample Data
INSERT INTO public.users (full_name, email, password, role, aadhaar_no, phone, address) VALUES 
('Rahul Sharma', 'rahul@gmail.com', 'pass1234', 'citizen', '123456789012', '9876543210', 'Scheme 54, Indore'),
('Priya Verma', 'priya@gmail.com', 'pass1234', 'citizen', '123456789013', '9876543211', 'Annapurna Road, Indore');

INSERT INTO public.users (full_name, email, password, role, aadhaar_no, phone, address, police_id_card_number) VALUES 
('Inspector Ramesh', 'ramesh@police.gov.in', 'officer123', 'police', '123456789014', '9000000001', 'Police HQ, Indore', 'POL-2026-0001');

INSERT INTO public.users (full_name, email, password, role, aadhaar_no, phone, address, authoritative_id) VALUES 
('Admin User', 'admin@efir.gov.in', 'admin@123', 'admin', '123456789015', '9000000000', 'Indore, MP', 'ADM-2026-0001');

INSERT INTO public.accused_details (name, age, gender, address, criminal_history) VALUES 
('Vicky Don', 32, 'Male', 'Malwa Mill, Indore', '3 Theft cases, 1 Assault'),
('Suresh Genda', 28, 'Male', 'Bhawarkua, Indore', 'Pickpocketing specialist');
