-- Major upgrade for E-FIR System
-- Author: Antigravity

-- 1. Updates to users table for role-specific IDs
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS police_id_card_number CHARACTER VARYING(50) UNIQUE;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS authoritative_id CHARACTER VARYING(50) UNIQUE;

-- 2. Updates to fir_reports for police assignment and media
ALTER TABLE public.fir_reports ADD COLUMN IF NOT EXISTS assigned_police_id INTEGER;
ALTER TABLE public.fir_reports ADD COLUMN IF NOT EXISTS media_paths TEXT; -- Comma-separated paths OR JSON

-- Add foreign key for assigned_police_id
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fir_reports_assigned_police_fkey') THEN
        ALTER TABLE public.fir_reports 
        ADD CONSTRAINT fir_reports_assigned_police_fkey 
        FOREIGN KEY (assigned_police_id) REFERENCES public.users(user_id);
    END IF;
END $$;

-- 3. Create case_updates table for timeline features
CREATE TABLE IF NOT EXISTS public.case_updates (
    update_id SERIAL PRIMARY KEY,
    fir_id INTEGER REFERENCES public.fir_reports(fir_id) ON DELETE CASCADE,
    police_id INTEGER REFERENCES public.users(user_id),
    update_text TEXT NOT NULL,
    status_at_time CHARACTER VARYING(30),
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Create notifications table for admin (New FIR alerts)
CREATE TABLE IF NOT EXISTS public.notifications (
    notification_id SERIAL PRIMARY KEY,
    message TEXT NOT NULL,
    role_target CHARACTER VARYING(20), -- 'admin', 'police', etc.
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
