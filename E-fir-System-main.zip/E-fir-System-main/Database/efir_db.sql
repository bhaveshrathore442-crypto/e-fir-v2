--
-- PostgreSQL database dump
--

\restrict O9yn85Q315Hv5YHBz9F5TF7rxZJO30Wqj9ZIDic609PHtVKQ1hpTp0eXPaaeThW

-- Dumped from database version 17.9
-- Dumped by pg_dump version 17.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: evidence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.evidence (
    evidence_id integer NOT NULL,
    fir_id integer,
    evidence_type character varying(50),
    description text,
    file_path character varying(255),
    uploaded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.evidence OWNER TO postgres;

--
-- Name: evidence_evidence_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.evidence_evidence_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.evidence_evidence_id_seq OWNER TO postgres;

--
-- Name: evidence_evidence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.evidence_evidence_id_seq OWNED BY public.evidence.evidence_id;


--
-- Name: fir_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fir_reports (
    fir_id integer NOT NULL,
    user_id integer,
    incident_type character varying(100) NOT NULL,
    incident_date date NOT NULL,
    incident_location text NOT NULL,
    description text NOT NULL,
    status character varying(30) DEFAULT 'Pending'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fir_number character varying(20) UNIQUE,
    accused_name character varying(255),
    accused_description text,
    accused_address text,
    accused_identification text,
    image_data bytea
);


ALTER TABLE public.fir_reports OWNER TO postgres;

--
-- Name: fir_reports_fir_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fir_reports_fir_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fir_reports_fir_id_seq OWNER TO postgres;

--
-- Name: fir_reports_fir_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fir_reports_fir_id_seq OWNED BY public.fir_reports.fir_id;


--
-- Name: police_stations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.police_stations (
    station_id integer NOT NULL,
    station_name character varying(100) NOT NULL,
    district character varying(100),
    city character varying(100),
    state character varying(100),
    phone character varying(15),
    address text
);


ALTER TABLE public.police_stations OWNER TO postgres;

--
-- Name: police_stations_station_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.police_stations_station_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.police_stations_station_id_seq OWNER TO postgres;

--
-- Name: police_stations_station_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.police_stations_station_id_seq OWNED BY public.police_stations.station_id;


--
-- Name: status_updates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status_updates (
    id integer NOT NULL,
    fir_id integer,
    updated_by integer,
    status character varying(30),
    remarks text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.status_updates OWNER TO postgres;

--
-- Name: status_updates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_updates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.status_updates_id_seq OWNER TO postgres;

--
-- Name: status_updates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_updates_id_seq OWNED BY public.status_updates.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    full_name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    aadhaar_no character varying(12) NOT NULL,
    phone character varying(10) NOT NULL,
    address text,
    role character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['citizen'::character varying, 'officer'::character varying, 'admin'::character varying, 'police'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: evidence evidence_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evidence ALTER COLUMN evidence_id SET DEFAULT nextval('public.evidence_evidence_id_seq'::regclass);


--
-- Name: fir_reports fir_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fir_reports ALTER COLUMN fir_id SET DEFAULT nextval('public.fir_reports_fir_id_seq'::regclass);


--
-- Name: police_stations station_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.police_stations ALTER COLUMN station_id SET DEFAULT nextval('public.police_stations_station_id_seq'::regclass);


--
-- Name: status_updates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_updates ALTER COLUMN id SET DEFAULT nextval('public.status_updates_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: evidence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.evidence (evidence_id, fir_id, evidence_type, description, file_path, uploaded_at) FROM stdin;
1	1	CCTV Footage	Footage from nearby shop	/uploads/fir1_cctv.mp4	2026-04-04 20:20:28.160358
2	2	Witness Statement	Statement from witness	/uploads/fir2_witness.pdf	2026-04-04 20:20:28.160358
\.


--
-- Data for Name: fir_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fir_reports (fir_id, user_id, incident_type, incident_date, incident_location, description, status, created_at, updated_at) FROM stdin;
1	1	Theft	2026-04-01	MG Road, Indore, MP	Mobile phone stolen from pocket while shopping at MG Road market near main gate.	Pending	2026-04-04 20:36:14.960074	2026-04-04 20:36:14.960074
2	2	Harassment	2026-04-02	Vijay Nagar, Indore, MP	Neighbor has been repeatedly harassing family members since last month.	Under Investigation	2026-04-04 20:36:14.960074	2026-04-04 20:36:14.960074
3	1	Theft	2026-03-01	MG Road, Indore, Madhya Pradesh	My mobile phone was stolen from my pocket while shopping at MG Road market near the main gate.	Pending	2026-04-04 20:37:36.471669	2026-04-04 20:37:36.471669
\.


--
-- Data for Name: police_stations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.police_stations (station_id, station_name, district, city, state, phone, address) FROM stdin;
1	MG Road Police Station	Indore	Indore	Madhya Pradesh	0731-2001001	MG Road, Indore
2	Vijay Nagar Police Station	Indore	Indore	Madhya Pradesh	0731-2001002	Vijay Nagar, Indore
\.


--
-- Data for Name: status_updates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status_updates (id, fir_id, updated_by, status, remarks, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, full_name, email, password, aadhaar_no, phone, address, role, created_at) FROM stdin;
1	Rahul Sharma	rahul@gmail.com	pass1234	123456789012	9876543210	Scheme 54, Indore	citizen	2026-04-04 20:20:28.160358
2	Priya Verma	priya@gmail.com	pass1234	123456789013	9876543211	Annapurna Road, Indore	citizen	2026-04-04 20:20:28.160358
3	Inspector Ramesh	ramesh@police.gov.in	officer123	123456789014	9000000001	Police HQ, Indore	police	2026-04-04 20:20:28.160358
4	Admin User	admin@efir.gov.in	admin@123	123456789015	9000000000	Indore, MP	admin	2026-04-04 20:20:28.160358
\.


--
-- Name: evidence_evidence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.evidence_evidence_id_seq', 2, true);


--
-- Name: fir_reports_fir_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fir_reports_fir_id_seq', 3, true);


--
-- Name: police_stations_station_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.police_stations_station_id_seq', 2, true);


--
-- Name: status_updates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_updates_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 4, true);


--
-- Name: evidence evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evidence
    ADD CONSTRAINT evidence_pkey PRIMARY KEY (evidence_id);


--
-- Name: fir_reports fir_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fir_reports
    ADD CONSTRAINT fir_reports_pkey PRIMARY KEY (fir_id);


--
-- Name: police_stations police_stations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.police_stations
    ADD CONSTRAINT police_stations_pkey PRIMARY KEY (station_id);


--
-- Name: status_updates status_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_updates
    ADD CONSTRAINT status_updates_pkey PRIMARY KEY (id);


--
-- Name: users users_aadhaar_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_aadhaar_no_key UNIQUE (aadhaar_no);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: fir_reports fir_reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fir_reports
    ADD CONSTRAINT fir_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: status_updates status_updates_fir_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_updates
    ADD CONSTRAINT status_updates_fir_id_fkey FOREIGN KEY (fir_id) REFERENCES public.fir_reports(fir_id);


--
-- Name: status_updates status_updates_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_updates
    ADD CONSTRAINT status_updates_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(user_id);


--
-- PostgreSQL database dump complete
--

\unrestrict O9yn85Q315Hv5YHBz9F5TF7rxZJO30Wqj9ZIDic609PHtVKQ1hpTp0eXPaaeThW

