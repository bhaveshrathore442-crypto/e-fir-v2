
-- Ensure fir_reports has all necessary columns
ALTER TABLE fir_reports ADD COLUMN IF NOT EXISTS police_station VARCHAR(100);
ALTER TABLE fir_reports ADD COLUMN IF NOT EXISTS assigned_police_id INTEGER REFERENCES users(user_id);
ALTER TABLE fir_reports ADD COLUMN IF NOT EXISTS progress_status VARCHAR(50);
ALTER TABLE fir_reports ADD COLUMN IF NOT EXISTS progress_description TEXT;
ALTER TABLE fir_reports ADD COLUMN IF NOT EXISTS media_paths TEXT;

-- Create case_updates table for timeline feature
CREATE TABLE IF NOT EXISTS case_updates (
    id SERIAL PRIMARY KEY,
    fir_id INTEGER REFERENCES fir_reports(fir_id),
    police_id INTEGER REFERENCES users(user_id),
    update_text TEXT NOT NULL,
    status_at_time VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Ensure evidence table is ready for multiple files
CREATE TABLE IF NOT EXISTS evidence (
    evidence_id SERIAL PRIMARY KEY,
    fir_id INTEGER REFERENCES fir_reports(fir_id),
    file_name VARCHAR(255),
    file_type VARCHAR(50),
    file_data BYTEA,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
