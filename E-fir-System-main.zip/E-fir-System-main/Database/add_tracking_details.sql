-- Update fir_reports table with progress and officer details
ALTER TABLE fir_reports 
ADD COLUMN IF NOT EXISTS police_station CHARACTER VARYING(100),
ADD COLUMN IF NOT EXISTS police_officer_name CHARACTER VARYING(100) DEFAULT 'Not Assigned',
ADD COLUMN IF NOT EXISTS progress_status CHARACTER VARYING(50) DEFAULT '0', -- Percentage or Step
ADD COLUMN IF NOT EXISTS progress_description TEXT DEFAULT 'FIR has been successfully registered. Waiting for officer assignment.';

-- Update status to have more variety if needed, but 'Pending' is already there.
-- We can set default status
ALTER TABLE fir_reports ALTER COLUMN status SET DEFAULT 'Pending';
