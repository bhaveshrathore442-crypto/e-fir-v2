@echo off
SETLOCAL

echo ============================================================
echo   EFIR System - Database Setup
echo ============================================================
echo.

:: Check for psql
psql --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] PostgreSQL 'psql' utility not found.
    echo Please ensure PostgreSQL is installed and its 'bin' folder is in your PATH.
    pause
    exit /b 1
)

echo [STEP 1] Creating database 'efir_db' (if it doesn't exist)...
:: Note: This might fail if the DB already exists, but we'll try to create it anyway
psql -U postgres -c "CREATE DATABASE efir_db;" 2>nul
if %errorlevel% neq 0 (
    echo [INFO] Database might already exist or permission denied. Proceeding to schema import...
)

echo [STEP 2] Importing schema and sample data...
echo (You may be prompted for your PostgreSQL password)
echo.
psql -U postgres -d efir_db -f "Database/full_setup.sql"

if %errorlevel% == 0 (
    echo.
    echo [SUCCESS] Database setup completed successfully!
) else (
    echo.
    echo [ERROR] Database import failed.
    echo Please check if 'efir_db.sql' exists in the 'Database' folder.
)

pause
ENDLOCAL
